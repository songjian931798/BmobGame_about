(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Game/game_wx.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'e5d4aWuVwhNzIQ9FzgC2/Rv', 'game_wx', __filename);
// scripts/Game/game_wx.js

// import Scene from '../base/scene'
// import Model from '../bmobgamesdk/bgsapi'
// import Rocker from '../views/rocker'
// import Music from '../runtime/music'
// import BackGround from '../views/background'
// import ImageButton from '../views/imagebutton'
// import TextButton from '../views/textbutton'
// import Sprite from '../base/sprite'
// import Layer from '../views/layer'

// const screenWidth = parseFloat(window.innerWidth),
//     screenHeight = parseFloat(window.innerHeight);
// const screenHalfWidth = screenWidth / 2,
//     screenHalfHeight = screenHeight / 2,
//     WidthRatio = 65535.0 / screenWidth,
//     HeightRatio = 65535.0 / screenHeight;

// const
//     ImgSrc_Player_Friend = 'images/friends/player.png',
//     ImgSrc_Player_Enemy = 'images/enemies/player.png',
//     ImgSrc_Fire_Friend = 'images/friends/fire.png',
//     ImgSrc_Fire_Enemy = 'images/enemies/fire.png',
//     ImgSrcs_Bot_Friend = [
//         'images/friends/bot0.png',
//         'images/friends/bot1.png',
//         'images/friends/bot2.png',
//         'images/friends/bot3.png'
//     ],
//     ImgSrcs_Bot_Enemy = [
//         'images/enemies/bot0.png',
//         'images/enemies/bot1.png',
//         'images/enemies/bot2.png',
//         'images/enemies/bot3.png'
//     ];
// const ImgSrc_Me = ImgSrc_Player_Friend;
// const PlayerWidth = screenWidth / 20; // 根据屏幕大小来定玩家的大小
// const PlayerHeight = PlayerWidth;
// const BotWidth = PlayerWidth,
//     BotHeight = PlayerHeight;
// const FireSpawnPosition = PlayerHeight / 2; // 开火的话，在半个身位前面发射
// const FireWidth = PlayerWidth / 8,
//     FireHeight = PlayerHeight;

// console.log('Player and Bot Size: ' + PlayerWidth);
// console.log('FireWidth Size: ' + FireWidth + ', ' + FireHeight);

// const
//     ReleaseXMin = -100,
//     ReleaseXMax = screenWidth + 100,
//     ReleaseYMin = -100,
//     ReleaseYMax = screenHeight + 100;

// const //
//     NotifyType_AssignTeam = 1, //
//     NotifyType_BotSpawn = 2, //
//     NotifyType_ReallyStart = 3, //
//     NotifyType_PlayerCrash = 4, //
//     NotifyType_BotDie = 5, //
//     NotifyType_GameOver = 6 //
// ;

// // 根据屏幕大小来定玩家的大小, 我们定玩家如果需要穿过整个y轴最少需要2秒，怪物需要8秒
// const PlayerMaxSpeed = screenHeight / 2000; // px per sec
// const BotSpeed = screenHeight / 8000; // px per sec
// const EnemyFireSpeed = screenHeight / 3000; // px per sec
// const FriendFireSpeed = -EnemyFireSpeed;

// let model = Model.instance;

// export default class Game extends Scene {
//     constructor() {
//         super("Game");
//     }

//     move(x, y, maxDist) {
//         if (x == 0 && y == 0)
//             return;

//         let ratio = Math.sqrt(x * x + y * y) / maxDist;
//         x = this.playerGameObj.x + x / ratio;
//         y = this.playerGameObj.y + y / ratio;

//         if (x < 0)
//             x = 0;
//         else if (x > screenWidth - this.playerGameObj.width)
//             x = screenWidth - this.playerGameObj.width;
//         if (y < 0)
//             y = 0;
//         else if (y > screenHeight - this.playerGameObj.height)
//             y = screenHeight - this.playerGameObj.height;

//         this.playerGameObj.x = x;
//         this.playerGameObj.y = y;

//         this.playerPosition[0] = parseInt((x + PlayerWidth / 2) * WidthRatio);
//         // y轴从上面0，到下面增加，和Unity相反(Unity是越往上y值越大)
//         // 由于Unity项目开发在先，为了能够跨平台玩，微信小游戏妥协为0xffff-y
//         // 既然已经0xffff-y了，那么敌队的坐标可以不用转换，队友坐标需要转换
//         this.playerPosition[1] = 65535 - parseInt((y + PlayerHeight / 2) * HeightRatio);
//         if (this.playerPosition[0] < 0)
//             this.playerPosition[0] = 0;
//         else if (this.playerPosition[0] > 65535)
//             this.playerPosition[0] = 65535;
//         if (this.playerPosition[1] < 0)
//             this.playerPosition[1] = 0;
//         else if (this.playerPosition[1] > 65535)
//             this.playerPosition[1] = 65535;

//         let editRes = model.EditMyStatus('position', this.playerPosition);
//         console.log('Edit my status:', editRes);
//     }

//     onUpdate() {
//         // vars
//         let ctx = this.ctx,
//             time = new Date().getTime(),
//             rocker = this.rocker;
//         let deltaTime = time - this.lastFrame;
//         // render
//         this.bg.render();

//         // 用户移动
//         if (this.isGameStart) {
//             this.move(rocker.x, rocker.y, deltaTime * PlayerMaxSpeed); // 移动角色
//             let gameObj;
//             let teamAlives = [
//                 [],
//                 []
//             ];
//             for (let i = 0, l = this.gameObjArr.length; i < l; i++) {
//                 gameObj = this.gameObjArr[i];
//                 if (gameObj.visible) {
//                     if (gameObj.x < ReleaseXMin || gameObj.x > ReleaseXMax ||
//                         gameObj.y < ReleaseYMin || gameObj.y > ReleaseYMax) {
//                         gameObj.visible = false;
//                         delete(this.gameObjMap[gameObj.name]);
//                     } else {
//                         if (gameObj.velocity)
//                             gameObj.y += gameObj.velocity * deltaTime;
//                         gameObj.onDraw(ctx);
//                         if (gameObj.teamId != 0 && gameObj.teamId != 1) {
//                             console.log('Game object: ' + gameObj.name + ' > ' + gameObj.objType + ', team id = ' + gameObj.teamId);
//                         }
//                         teamAlives[gameObj.teamId].push(gameObj);
//                         if (gameObj.isOpenFire) {
//                             if (time > gameObj.nextFire) {
//                                 gameObj.nextFire = time + gameObj.fireSpan;
//                                 let fire = new Sprite(
//                                     gameObj.fireSrc,
//                                     FireWidth,
//                                     FireHeight,
//                                     gameObj.x + gameObj.width / 2,
//                                     gameObj.y + (gameObj.teamId == this.mTeamId ? (-gameObj.height / 2) : (gameObj.height * 3 / 2))
//                                 );
//                                 fire.objType = 3; // 0: sundries; 1: player; 2: bot; 3: fire
//                                 fire.velocity = gameObj.fireSpeed;
//                                 fire.teamId = gameObj.teamId;
//                                 teamAlives[gameObj.teamId].push(fire); // 下一帧才渲染
//                                 if (gameObj.playerNo === this.mNo) {
//                                     // 我发射的炮弹，要通知其它人
//                                     let x = parseInt(fire.x * WidthRatio),
//                                         y = parseInt(fire.y * HeightRatio);
//                                     y = 65535 - y;
//                                     model.SendTransferToAllExceptSelf([50, x >> 8, x & 0xff, y >> 8, y & 0xff]);
//                                     console.log('我发射炮弹:' + [50, x >> 8, x & 0xff, y >> 8, y & 0xff]);
//                                 }
//                             }
//                         }
//                     }
//                 } else
//                     delete(this.gameObjMap[gameObj.name]);
//             }
//             let friends = teamAlives[this.mTeamId],
//                 enemies = teamAlives[1 - this.mTeamId];
//             for (let fi = 0, fc = friends.length; fi < fc; fi++) {
//                 let friend = friends[fi];
//                 for (let ei = 0, ec = enemies.length; ei < ec && friend.visible; ei++) {
//                     let enemy = enemies[ei];
//                     if (friend.isCollideWith(enemy)) { // 这个方法里面已经有双方visible的判断
//                         console.log('Collide! one is [' + friend.name + '](' + friend.objType + ') and another is [' + enemy.name + '](' + enemy.objType + ')');
//                         // 1. 如果双方是bot+fire组合，那么bot扣血，fire消失
//                         // 2. 其它无论何种情况，都是一起消失
//                         if (friend.objType + enemy.objType == 5) { // 只有2+3组合,不存在0+5和1+4组合
//                             let botOne, fireOne;
//                             if (friend.objType == 2) { // bot friend hit
//                                 botOne = friend;
//                                 fireOne = enemy;
//                             } else {
//                                 botOne = enemy;
//                                 fireOne = friend;
//                             }
//                             botOne.botHp--;
//                             if (botOne.botHp == 0)
//                                 this.objDie(botOne);
//                             this.objDie(fireOne);
//                         } else { // both die
//                             this.objDie(friend, enemy);
//                             this.objDie(enemy, friend);
//                         }
//                     }
//                 }
//             }
//             this.gameObjArr = friends.concat(enemies);
//             console.log('Alive game object count: ' + this.gameObjArr.length);
//         }
//         // this.player.onDraw(ctx);

//         // 文字层
//         if (this.mainInfo) {
//             if (this.mainInfo[0] < time) // 过时了
//                 this.mainInfo = null;
//             else
//                 this.drawTextAtCenter((screenWidth >> 2) + 40, screenHeight - 14 - 108 - 22, screenWidth >> 1, 22, this.mainInfo[1], 18, '#ffffff');
//         }
//         let deadInfos = this.cleanDeadInfo(time); // 清理上方显示的内容
//         for (let i = 0, l = deadInfos.length; i < l; i++)
//             this.drawTextAtCenter((screenWidth >> 2) + 20, 10 + i * 14, screenWidth >> 1, 14, deadInfos[i][1], 12, '#ffffff');

//         rocker.render();
//         this.lastFrame = time;
//     }

//     objDie(obj, murderer) {
//         console.log('Obj die: ' + obj.name);
//         switch (obj.objType) {
//             case 1: // player
//                 let crashInfo = [obj.playerNo, 1, 0];
//                 if (murderer.objType == 1) {
//                     crashInfo[1] = 0;
//                     crashInfo[2] = murderer.playerNo;
//                 } else if (murderer.objType == 2)
//                     crashInfo[1] = 2;
//                 model.CloudAction('PlayerCrash', crashInfo);
//                 break;
//             case 2: // bot
//                 model.CloudAction('BotDie', model.stringToBytes(obj.name));
//                 break;
//                 // case 3: fire
//         }
//         obj.visible = false; // 本地就让物体消失,减小碰撞负担,但如果需要严谨一点的话，这一行可以去掉，因为服务器会通知
//     }

//     onStart() {
//         this.gameObjArr = [];
//         this.gameObjMap = {};

//         this.isGameStart = false;
//         this.mOfflineListener = this.onOffline.bind(this);
//         model.RegistOfflineListener(this.mOfflineListener);

//         this.mScore = 0;
//         this.rocker = new Rocker(ctx, screenWidth >> 2, [20, 0, 0, 20]);
//         this.resources = [];
//         this.playerCount = parseInt(model.get('playerCount', 1));
//         this.players = new Array(this.playerCount);
//         this.mNo = parseInt(model.get('mNo', 0));
//         this.startTime = parseInt(model.get('startTime', new Date().getTime() - 10));
//         this.l('游戏开始时间️: ' + new Date(this.startTime * 10));
//         this.deadInfos = [];

//         let playerNames = model.get('players');
//         if (playerNames) {
//             if (typeof(playerNames) == 'string')
//                 try {
//                     playerNames = JSON.parse(playerNames);
//                 } catch (e) {
//                     playerNames = null;
//                 }
//             else if (playerNames.length != this.playerCount)
//                 playerNames = null;
//         }
//         if (!playerNames)
//             playerNames = new Array(this.playerCount);

//         for (let i = 0; i < this.playerCount; i++)
//             this.players[i] = {
//                 no: i,
//                 name: playerNames[i] ? ('玩家' + (i + 1)) : playerNames[i]
//             };
//         this.music = new Music();
//         this.bg = new BackGround(this.ctx);

//         // this.player = new Player(screenHalfWidth - 30, screenHeight - 60);
//         // this.playerPosition = [this.player.x * WidthRatio, this.player.y * HeightRatio];

//         this.touchListeners.push(this.rocker);

//         model.SetGameRuntimeListeners(
//             this.onGameInfo.bind(this),
//             this.onMyStatus.bind(this),
//             this.onOthersStatus.bind(this),
//             this.onTransfer.bind(this),
//             this.onCloudNotify.bind(this)
//         );

//         model.CloudAction('OnGameLoad');
//     }

//     onOffline() {
//         this.showMainInfo('与服务器断开连接');
//         setTimeout(this.doBackToLobby.bind(this), 3000);
//     }

//     onGameInfo(action, no, data) {
//         console.log('OnGameInfo:', arguments);
//     }

//     onMyStatus(changedAttr, myStatus) {
//         console.log('onMyStatus:', arguments);
//     }

//     onOthersStatus(no, changedAttr, hisStatus) {
//         console.log('On other status:', arguments);
//         if (changedAttr.position) {
//             let y = hisStatus.position[1];
//             let gameObj = this.players[no].gameObject;
//             if (gameObj.isTeammate)
//                 y = 65535 - y;
//             gameObj.x = hisStatus.position[0] / WidthRatio - PlayerWidth / 2;
//             gameObj.y = y / HeightRatio - PlayerHeight / 2;

//             console.log('Player[' + no + '] change positions to (' + gameObj.x + ', ' + gameObj.y + ')');
//         }
//     }

//     onTransfer(no, body) {
//         switch (body.shift()) {
//             case 50:
//                 console.log('Fire from: ', this.players[no]);
//                 let isTeammate = this.players[no].gameObject.isTeammate,
//                     x = (body[0] << 8) | body[1],
//                     y = (body[2] << 8) | body[3];
//                 if (isTeammate)
//                     y = 65535 - y;

//                 let fire = new Sprite(
//                     isTeammate ? ImgSrc_Fire_Friend : ImgSrc_Fire_Enemy,
//                     FireWidth,
//                     FireHeight,
//                     x / WidthRatio,
//                     y / HeightRatio
//                 );
//                 fire.objType = 3; // 0: sundries; 1: player; 2: bot; 3: fire
//                 fire.velocity = isTeammate ? FriendFireSpeed : EnemyFireSpeed;
//                 fire.teamId = isTeammate ? this.mTeamId : (1 - this.mTeamId);
//                 this.gameObjArr.push(fire);
//                 break;
//         }
//     }

//     startGame() {
//         this.isGameStart = true;
//     }

//     onCloudNotify(notify) {
//         switch (notify.shift()) {
//             case NotifyType_AssignTeam:
//                 this.assignTeam(notify);
//                 break;
//             case NotifyType_BotSpawn:
//                 this.botSpawn(
//                     notify[0] == this.mTeamId,
//                     (notify[1]) * screenWidth / 255,
//                     notify[2],
//                     model.bytesToString(notify, 3, notify.length)
//                 );
//                 break;
//             case NotifyType_ReallyStart:
//                 this.startGame();
//                 break;
//             case NotifyType_PlayerCrash:
//                 this.renderPlayerDie(notify[0]);
//                 break;
//             case NotifyType_BotDie:
//                 this.botDie(model.bytesToString(notify, 0, notify.length));
//                 break;
//             case NotifyType_GameOver:
//                 this.isGameStart = false;
//                 switch (notify[0]) {
//                     case 0:
//                         this.gameDraw();
//                         break;
//                     case 1:
//                         this.gameWin();
//                         break;
//                     case 2:
//                         this.gameLose();
//                         break;
//                 }
//                 break;
//         }
//     }

//     gameDraw() {
//         this.showMainInfo('平局!');
//         setTimeout(this.doBackToRoom.bind(this), 3000);
//     }
//     gameWin() {
//         this.showMainInfo('胜利!');
//         setTimeout(this.doBackToRoom.bind(this), 3000);
//     }
//     gameLose() {
//         this.showMainInfo('失败');
//         setTimeout(this.doBackToRoom.bind(this), 3000);

//     }

//     botSpawn(isTeammate, fromX, botType, name) {
//         let bot = new Sprite(
//             (isTeammate ? ImgSrcs_Bot_Friend : ImgSrcs_Bot_Enemy)[botType],
//             BotWidth,
//             BotHeight,
//             fromX,
//             isTeammate ? screenHeight : -BotHeight
//         );
//         bot.velocity = isTeammate ? -BotSpeed : BotSpeed;
//         bot.name = name;
//         bot.teamId = isTeammate ? this.mTeamId : 1 - this.mTeamId;
//         bot.objType = 2; // 0: sundries; 1: player; 2: bot; 3: fire
//         switch (botType) {
//             case 0:
//                 bot.botHp = 2;
//                 break;
//             case 1:
//                 bot.botHp = 3;
//                 bot.velocity *= 1.2;
//                 break;
//             case 2:
//                 bot.botHp = 4;
//                 bot.velocity *= 1.5;
//                 bot.isOpenFire = true;
//                 bot.fireSpan = 2000;
//                 bot.nextFire = 0;
//                 bot.fireSrc = isTeammate ? ImgSrc_Fire_Friend : ImgSrc_Fire_Enemy;
//                 bot.fireSpeed = isTeammate ? FriendFireSpeed : EnemyFireSpeed;
//                 break;
//             case 3:
//                 bot.botHp = 4;
//                 bot.velocity *= 2;
//                 bot.isOpenFire = true;
//                 bot.fireSpan = 1000;
//                 bot.nextFire = 0;
//                 bot.fireSrc = isTeammate ? ImgSrc_Fire_Friend : ImgSrc_Fire_Enemy;
//                 bot.fireSpeed = isTeammate ? FriendFireSpeed : EnemyFireSpeed;
//                 break;
//         }
//         this.appendGameObject(bot);
//     }
//     botDie(name) {
//         let obj = this.gameObjMap[name];
//         if (obj) {
//             // 也许需要一些爆炸效果
//             console.log('Bot die: ' + name);
//             obj.visible = false;
//         }
//     }
//     renderPlayerDie(no) {
//         let player = this.gameObjMap['Player_' + no];
//         if (player) {
//             // 也许需要一些爆炸效果
//             player.visible = false;
//         }
//     }
//     assignTeam(teamInfo) {
//         this.mTeamId = teamInfo[this.mNo];

//         for (let i = 0; i < this.playerCount; i++) {
//             let player;
//             if (i == this.mNo) { // 我自己
//                 player = new Sprite(
//                     ImgSrc_Me,
//                     PlayerWidth,
//                     PlayerHeight,
//                     screenHalfWidth - PlayerWidth / 2,
//                     screenHeight - PlayerHeight
//                 );

//                 player.isOpenFire = true;
//                 player.fireSpan = 1000;
//                 player.nextFire = 0;
//                 player.fireSrc = ImgSrc_Fire_Friend;
//                 player.fireSpeed = FriendFireSpeed;

//                 this.playerGameObj = player;
//                 this.playerPosition = [player.x * WidthRatio, player.y * HeightRatio];
//             } else if (teamInfo[i] == this.mTeamId) { // 队友
//                 player = new Sprite(
//                     ImgSrc_Player_Friend,
//                     PlayerWidth,
//                     PlayerHeight,
//                     screenHalfWidth - PlayerWidth / 2,
//                     screenHeight - PlayerHeight
//                 );
//             } else { // 敌人
//                 player = new Sprite(
//                     ImgSrc_Player_Enemy,
//                     PlayerWidth,
//                     PlayerHeight,
//                     screenHalfWidth - PlayerWidth / 2,
//                     0
//                 );
//             }
//             player.name = "Player_" + i;
//             player.teamId = teamInfo[i];
//             player.isTeammate = player.teamId === this.mTeamId;
//             player.isPlayer = true;
//             player.objType = 1; // 0: sundries; 1: player; 2: bot; 3: fire
//             player.playerNo = i;
//             this.appendGameObject(player);
//             this.players[i].gameObject = player;
//         }

//         console.log('Assign team:', this.players);
//         model.CloudAction('OnTeamInfoGet');
//     }

//     appendGameObject(obj) {
//         if (obj) {
//             if (obj.name)
//                 this.gameObjMap[obj.name] = obj;
//             this.gameObjArr.push(obj);
//         }
//     }

//     onTouchEvent(x, y, a, e) {}

//     onDestroy() {
//         this.gameObjArr = null;
//         this.gameObjMap = null;
//         this.isGameStart = false;
//         model.UnregistOfflineListener(this.mOfflineListener);
//         model.StopGameRuntimeListener();
//         this.mOfflineListener = null;

//         this.mScore = null;
//         this.playerPosition = null;
//         this.rocker = null;
//         this.music.destroyAll();
//         this.music = null;
//         this.deadInfos = null;
//         this.mainInfo = null;
//         model.QuitRoom();
//     }
//     doBackToRoom() {
//         this.loadScene('room');
//     }
//     doBackToLobby() {
//         this.loadScene('lobby');
//     }
//     addDeadInfo(msg) {
//         this.deadInfos.push([new Date().getTime() + 5000, msg]);
//     }
//     showMainInfo(msg) {
//         this.mainInfo = [new Date().getTime() + 5000, msg];
//     }
//     cleanDeadInfo(time) {
//         let deadInfos = this.deadInfos;
//         let deadInfoCount = deadInfos.length;
//         if (deadInfoCount == 0)
//             return [];

//         if (deadInfoCount > 3)
//             deadInfos = deadInfos.slice(deadInfoCount - 3);
//         let resultInfos = [];
//         for (let i = 0, l = deadInfos.length; i < l; i++)
//             if (time < deadInfos[i][0])
//                 resultInfos.push(deadInfos[i]);
//         this.deadInfos = resultInfos;
//         return resultInfos;
//     }
// }
"use strict";

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=game_wx.js.map
        