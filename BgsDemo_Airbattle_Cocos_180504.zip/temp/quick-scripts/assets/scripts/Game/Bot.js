(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Game/Bot.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'a8c2deyw7RPd7EzU4ZR2H8D', 'Bot', __filename);
// scripts/Game/Bot.js

'use strict';

var MovableObj = require("MovableObj");
var Bgs = require('bgsapi');

cc.Class({
    extends: MovableObj,

    properties: {
        fire: {
            default: null,
            type: cc.Prefab
        },
        botHp: 2,
        fireSpan: 0.0
    },

    onSubLoad: function onSubLoad() {
        var size = this.node.parent.width / 20;
        this.node.scaleX = size / this.node.width;
        this.node.scaleY = size / this.node.height;

        if (this.fireSpan > 0 && this.fire != null) {
            this.isOpenFile = true;
            this.nextFire = 0;

            this.spawnY = this.node.height;
            if (this.node.group == 'Enemy') {
                this.spawnY = -this.spawnY;
            }
        } else {
            this.isOpenFile = false;
        }
    },
    botDie: function botDie(name) {
        console.log('Local bot die:', name);
        Bgs.CloudAction('BotDie', Bgs.stringToBytes(name));
    },


    onCollisionEnter: function onCollisionEnter(other, self) {
        other = other.node;
        self = self.node;
        // console.log('Bot onCollisionEnter: ', other, self);
        switch (other.objType) {
            case 1:
                this.botDie(self.name);
                break;
            case 2:
                this.botDie(other.name);
                this.botDie(self.name);
                break;
            case 3:
                this.botHp--;
                if (this.botHp == 0) this.botDie(self.name);
                break;
            default:
                console.log('Bot collision:', other.objType, other);
                break;
        }
    },

    onSubUpdate: function onSubUpdate(dt) {
        if (this.isOpenFile) {
            var curTime = new Date().getTime();
            if (curTime > this.nextFire) {
                this.nextFire = curTime + this.fireSpan;
                var fire = cc.instantiate(this.fire);
                this.node.parent.addChild(fire);
                fire.setPosition(this.node.x, this.node.y + this.spawnY);
            }
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Bot.js.map
        