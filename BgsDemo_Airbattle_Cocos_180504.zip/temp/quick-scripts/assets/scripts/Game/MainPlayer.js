(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Game/MainPlayer.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'b2a39yynutNxLw0Q76PpAg3', 'MainPlayer', __filename);
// scripts/Game/MainPlayer.js

'use strict';

var Bgs = require('bgsapi');

cc.Class({
    extends: cc.Component,

    properties: {
        friendFire: {
            default: null,
            type: cc.Prefab
        },
        fireSpan: 1000,
        nextFire: new Date().getTime() * 2
    },

    planeCrash: function planeCrash(plane, murderer) {
        var crashInfo = [plane.playerNo, 1, 0];
        if (murderer.objType == 1) {
            crashInfo[1] = 0;
            crashInfo[2] = murderer.playerNo;
        } else if (murderer.objType == 2) crashInfo[1] = 2;
        Bgs.CloudAction('PlayerCrash', crashInfo);
    },


    onCollisionEnter: function onCollisionEnter(other, self) {
        console.log('Main player is crash');
        this.planeCrash(self.node, other.node);
    },

    onLoad: function onLoad() {
        var size = this.node.parent.width / 20;
        this.node.scaleX = size / this.node.width;
        this.node.scaleY = size / this.node.height;
    },
    update: function update(dt) {
        var curTime = new Date().getTime();
        if (curTime > this.nextFire) {
            this.nextFire = curTime + this.fireSpan;
            var fire = cc.instantiate(this.friendFire);
            this.node.parent.addChild(fire);
            var x = this.node.x,
                y = this.node.y + this.node.height / 2;
            fire.setPosition(x, y);
            x = parseInt(x * this.WidthRatio);
            y = parseInt(y * this.HeightRatio);
            Bgs.SendTransferToAllExceptSelf([50, x >> 8, x & 0xff, y >> 8, y & 0xff]);
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=MainPlayer.js.map
        