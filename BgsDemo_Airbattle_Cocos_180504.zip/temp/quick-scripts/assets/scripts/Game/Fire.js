(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Game/Fire.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'fb57crf0LRD14ly3oMdcEtE', 'Fire', __filename);
// scripts/Game/Fire.js

"use strict";

var MovableObj = require("MovableObj");

cc.Class({
    extends: MovableObj,

    properties: {},

    onSubLoad: function onSubLoad() {
        var size = this.node.parent.width / 20;
        this.node.scaleX = size / (this.node.width * 8);
        this.node.scaleY = size / this.node.height;
    },
    onSubUpdate: function onSubUpdate(dt) {},


    onCollisionEnter: function onCollisionEnter(other, self) {
        console.log('Bullet touch sb');
        this.node.destroy();
        // console.log('Fire onCollisionEnter: ', other, self);
    }

});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Fire.js.map
        