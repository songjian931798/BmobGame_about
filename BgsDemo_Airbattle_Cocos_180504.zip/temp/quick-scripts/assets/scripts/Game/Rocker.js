(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Game/Rocker.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '820b8igIcVBAryGjJk1tF+h', 'Rocker', __filename);
// scripts/Game/Rocker.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        body: {
            default: null,
            type: cc.Node
        },
        heart: {
            default: null,
            type: cc.Node
        }
    },

    start: function start() {
        this.vector = [0, 0];

        if (!this.body || !this.heart) return;

        this.actSize = this.body.width / 2;
        this.actArea = this.actSize * this.actSize;
        // this.heartX = this.heart.x;
        // this.heartY = this.heart.y;
        // this.heart.on(cc.Node.EventType.TOUCH_START, this.onTouchStart.bind(this));
        // this.heart.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove.bind(this));
        // this.heart.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd.bind(this));
    },


    // isInside(v2) {
    //     let lo = this.node.convertToNodeSpace(v2);
    //     let at = (lo.x > -this.actSize && lo.x < this.actSize && lo.y > -this.actSize && lo.y < this.actSize);
    //     console.log("It's inside: ", lo, at);
    //     return at;
    // },

    // 返回单位向量
    moveTo: function moveTo(x, y) {
        // v2 = this.node.convertToNodeSpace(v2);
        // let x = v2.x,
        //     y = v2.y;
        var len = x * x + y * y;
        if (len > this.actArea) {
            var ratio = this.actSize / Math.sqrt(len);
            x *= ratio;
            y *= ratio;
        }
        this.heart.setPosition(x, y);

        this.vector = [x / this.actSize, y * 1 / this.actSize];

        // console.log('normalRatio: ', normalRatio);
        // console.log('Rocker vec: ', this.vector);
    },
    getVector: function getVector() {
        // let point = this.heart.getPosition();
        // let x = point.x,
        //     y = point.y;
        // let len = x * x + y * y;
        // let ratio = this.actSize / Math.sqrt(len);
        // return [x * ratio, y * ratio];
        return this.vector;
    }
}

// onTouchStart(event) {
//     // console.log('onTouchStart:', arguments);
//     this.touching = event.touch;
//     let lo = event.touch.getLocation();
//     this.touchX = lo.x;
//     this.touchY = lo.y;
// },

// onTouchMove(event) {
//     // console.log('onTouchMove:', arguments);
//     console.log('Same: ' + (event == this.touching));
//     let lo = event.touch.getLocation();
//     let x = (lo.x - this.touchX),
//         y = (lo.y - this.touchY);
//     let len = x * x + y * y;
//     if (len > this.actArea) {
//         let ratio = this.actSize / Math.sqrt(len);
//         x *= ratio;
//         y *= ratio;
//     }
//     this.heart.setPosition(x, y);
// },

// onTouchEnd() {
//     this.touching = null;
//     // console.log('onTouchEnd:', arguments);
//     this.heart.setPosition(0, 0);
// },

// update(dt) {
//     if (this.touching) {

//     }
// },

);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Rocker.js.map
        