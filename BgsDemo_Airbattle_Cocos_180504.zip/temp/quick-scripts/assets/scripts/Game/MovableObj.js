(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Game/MovableObj.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'b20f3SD0/JERZdO74G9+2MM', 'MovableObj', __filename);
// scripts/Game/MovableObj.js

"use strict";

var MovableObj = cc.Class({
    extends: cc.Component,

    properties: {
        crossYCostMillSec: 0.0
    },

    onLoad: function onLoad() {
        var w = this.node.parent.width,
            h = this.node.parent.height;

        if (this.crossYCostMillSec == 0) this.speed = 0;else this.speed = 1000 * h / this.crossYCostMillSec;

        this.xMin = -w / 4;
        this.yMin = -h / 4;
        this.xMax = w + w / 4;
        this.yMax = h + h / 4;

        // console.log(this.name + ' > speed = ' + this.speed);

        this.onSubLoad();
    },
    update: function update(dt) {
        var y = dt * this.speed + this.node.y;
        if (y < this.yMin || y > this.yMax) {
            // console.log('destroy!', this);
            this.node.destroy();
            return;
        }
        var x = this.node.x;
        if (x < this.xMin || x > this.xMax) {
            this.node.destroy();
            return;
        }
        this.node.y = y;
        this.onSubUpdate(dt);
    }
});

module.exports = MovableObj;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=MovableObj.js.map
        