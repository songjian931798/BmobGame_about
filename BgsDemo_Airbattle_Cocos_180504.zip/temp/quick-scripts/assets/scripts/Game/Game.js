(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Game/Game.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '48e61/p/jFPvZue0eSDHAKt', 'Game', __filename);
// scripts/Game/Game.js

'use strict';

var zutils = require('ZwrCocosUtil');
var Rocker = require('Rocker');
var Bgs = require('bgsapi');

var //
NotifyType_AssignTeam = 1,
    //
NotifyType_BotSpawn = 2,
    //
NotifyType_ReallyStart = 3,
    //
NotifyType_PlayerCrash = 4,
    //
NotifyType_BotDie = 5,
    //
NotifyType_GameOver = 6 //
;

cc.Class({
    extends: cc.Component,

    properties: {
        alertText: {
            default: null,
            type: cc.Label
        },
        mainPlayer: {
            default: null,
            type: cc.Prefab
        },
        friends: {
            default: [],
            type: cc.Prefab
        },
        enemies: {
            default: [],
            type: cc.Prefab
        },
        friendFire: {
            default: null,
            type: cc.Prefab
        },
        enemyFire: {
            default: null,
            type: cc.Prefab
        },
        rocker: {
            default: null,
            type: Rocker
        }
    },

    onLoad: function onLoad() {
        zutils.FixSize(this.node);
        cc.director.getCollisionManager().enabled = true;
        this.alertText.string = '';

        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart.bind(this));
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove.bind(this));
        this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd.bind(this));

        if (zutils.IsGameDebug) {
            this._mainPlayer = cc.instantiate(this.mainPlayer);
            this._mainPlayer.x = 100;
            this._mainPlayer.y = 100;
            this.node.addChild(this._mainPlayer);
            this.isGameStart = true;
            return;
        }

        this.WidthRatio = 65535 / this.node.width;
        this.HeightRatio = 65535 / this.node.height;
        this.playerPosition = [0, 0];

        this.isGameStart = false;
        this.mOfflineListener = this.onOffline.bind(this);
        Bgs.RegistOfflineListener(this.mOfflineListener);

        this.playerCount = parseInt(Bgs.get('playerCount', 1));
        this.players = new Array(this.playerCount);
        this.mNo = parseInt(Bgs.get('mNo', 0));
        this.startTime = parseInt(Bgs.get('startTime', new Date().getTime() - 10));
        console.log('游戏开始时间️: ' + new Date(this.startTime * 10));

        var playerNames = Bgs.get('players');
        if (playerNames) {
            if (typeof playerNames == 'string') try {
                playerNames = JSON.parse(playerNames);
            } catch (e) {
                console.log(e);
                playerNames = null;
            } else if (playerNames.length != this.playerCount) playerNames = null;
        }
        if (!playerNames) playerNames = new Array(this.playerCount);

        for (var i = 0; i < this.playerCount; i++) {
            this.players[i] = {
                no: i,
                name: playerNames[i] ? playerNames[i] : '玩家' + (i + 1)
            };
        }Bgs.SetGameRuntimeListeners(this.onGameInfo.bind(this), this.onMyStatus.bind(this), this.onOthersStatus.bind(this), this.onTransfer.bind(this), this.onCloudNotify.bind(this));

        Bgs.CloudAction('OnGameLoad');
        console.log('发送了OnGameLoad，等待下一步响应');
    },
    alert: function alert(msg) {
        console.log(msg);
        this.alertText.string = msg;
    },
    onOffline: function onOffline() {
        this.alert('与服务器断开连接');
        setTimeout(this.doBackToLobby.bind(this), 3000);
    },
    onTouchStart: function onTouchStart(event) {
        var point = event.touch.getLocation();
        var x = point.x / this.node.scaleX,
            y = point.y;
        this.rocker.node.x = x;
        this.rocker.node.y = y;
        this.lastX = x;
        this.lastY = y;
        this.rocker.node.opacity = 255;
        this.touchWho = 1;
    },
    onTouchMove: function onTouchMove(event) {
        switch (this.touchWho) {
            case 1:
                var point = event.touch.getLocation();
                this.rocker.moveTo(point.x / this.node.scaleX - this.lastX, point.y - this.lastY);
                break;
        }
    },
    onTouchEnd: function onTouchEnd(event) {
        switch (this.touchWho) {
            case 1:
                this.rocker.moveTo(0, 0);
                this.rocker.node.opacity = 0;
                break;
        }
    },
    update: function update(dt) {
        if (this.isGameStart) {
            var move = this.rocker.getVector();
            var speed = 200;
            var x = move[0] * speed * dt,
                y = move[1] * speed * dt;
            x += this._mainPlayer.x;
            y += this._mainPlayer.y;

            if (x < 0) x = 0;else if (x > 960) x = 960;
            if (y < 0) y = 0;else if (y > 640) y = 640;

            this._mainPlayer.setPosition(x, y);

            this.playerPosition[0] = parseInt(x * this.WidthRatio);
            this.playerPosition[1] = parseInt(y * this.HeightRatio);

            Bgs.EditMyStatus('position', this.playerPosition);
        }
    },
    onDestroy: function onDestroy() {
        this.isGameStart = false;
        Bgs.UnregistOfflineListener(this.mOfflineListener);
        Bgs.StopGameRuntimeListener();
        this.mOfflineListener = null;
        Bgs.QuitRoom();
    },
    doBackToRoom: function doBackToRoom() {
        cc.director.loadScene('Room');
    },
    doBackToLobby: function doBackToLobby() {
        cc.director.loadScene('Lobby');
    },
    onGameInfo: function onGameInfo(action, no, data) {
        console.log('OnGameInfo:', arguments);
    },
    onMyStatus: function onMyStatus(changedAttr, myStatus) {
        console.log('onMyStatus:', arguments);
    },
    onOthersStatus: function onOthersStatus(no, changedAttr, hisStatus) {
        if (changedAttr.position) {
            var y = hisStatus.position[1];
            var gameObject = this.players[no].gameObject;
            if (!gameObject.isTeammate) y = 65535 - y;
            gameObject.x = hisStatus.position[0] / this.WidthRatio;
            gameObject.y = y / this.HeightRatio;
        }
    },
    onTransfer: function onTransfer(no, body) {
        switch (body.shift()) {
            case 50:
                var isTeammate = this.players[no].gameObject.isTeammate,
                    x = body[0] << 8 | body[1],
                    y = body[2] << 8 | body[3];
                if (!isTeammate) y = 65535 - y;

                var fire = cc.instantiate(isTeammate ? this.friendFire : this.enemyFire);
                this.node.addChild(fire);
                fire.setPosition(x / this.WidthRatio, y / this.HeightRatio);
                fire.objType = 3; // 0: sundries; 1: player; 2: bot; 3: fire
                fire.teamId = isTeammate ? this.mTeamId : 1 - this.mTeamId;
                break;
        }
    },
    onCloudNotify: function onCloudNotify(notify) {
        console.log('onCloudNotify: ' + notify[0]);
        switch (notify.shift()) {
            case NotifyType_AssignTeam:
                this.assignTeam(notify);
                break;
            case NotifyType_BotSpawn:
                this.botSpawn(notify[0] == this.mTeamId, notify[1] * this.node.width / 255, notify[2], Bgs.bytesToString(notify, 3, notify.length));
                break;
            case NotifyType_ReallyStart:
                this.isGameStart = true;
                this.mainPlayerScript.nextFire = 0;
                break;
            case NotifyType_PlayerCrash:
                this.renderPlayerDie(notify[0]);
                break;
            case NotifyType_BotDie:
                this.botDie(Bgs.bytesToString(notify, 0, notify.length));
                break;
            case NotifyType_GameOver:
                this.isGameStart = false;
                switch (notify[0]) {
                    case 0:
                        this.gameDraw();
                        break;
                    case 1:
                        this.gameWin();
                        break;
                    case 2:
                        this.gameLose();
                        break;
                }
                break;
        }
    },
    gameDraw: function gameDraw() {
        this.alert('平局!');
        setTimeout(this.doBackToRoom.bind(this), 3000);
    },
    gameWin: function gameWin() {
        this.alert('胜利!');
        setTimeout(this.doBackToRoom.bind(this), 3000);
    },
    gameLose: function gameLose() {
        this.alert('失败');
        setTimeout(this.doBackToRoom.bind(this), 3000);
    },
    botSpawn: function botSpawn(isTeammate, fromX, botType, name) {
        var bot = cc.instantiate((isTeammate ? this.friends : this.enemies)[botType]);
        bot.name = name;
        bot.teamId = isTeammate ? this.mTeamId : 1 - this.mTeamId;
        bot.objType = 2; // 0: sundries; 1: player; 2: bot; 3: fire
        this.node.addChild(bot);
        bot.x = fromX;
        bot.y = isTeammate ? -bot.height / 2 : this.node.height + bot.height / 2;
    },
    botDie: function botDie(name) {
        var bot = cc.find(name, this.node);
        console.log('Find die bot:', name, bot);
        if (bot) {
            // 也许需要一些爆炸效果
            bot.destroy();
        }
    },
    renderPlayerDie: function renderPlayerDie(no) {
        // 也许需要一些爆炸效果
        console.log('Player die:', no, this.players[no]);
        this.players[no].gameObject.destroy();
    },
    assignTeam: function assignTeam(teamInfo) {
        this.mTeamId = teamInfo[this.mNo];

        var horiSpan = this.node.width / (this.playerCount + 2);

        for (var i = 0; i < this.playerCount; i++) {
            var player = void 0;
            if (i == this.mNo) {
                // 我自己
                player = cc.instantiate(this.mainPlayer);
                this._mainPlayer = player;
                this.mainPlayerScript = player.getComponent('MainPlayer');
                this.mainPlayerScript.WidthRatio = this.WidthRatio;
                this.mainPlayerScript.HeightRatio = this.HeightRatio;
            } else if (teamInfo[i] == this.mTeamId) {
                // 队友
                player = cc.instantiate(this.friends[4]);
            } else {
                // 敌人
                player = cc.instantiate(this.enemies[4]);
            }
            var nameLabel = cc.find('name', player).getComponent(cc.Label);
            if (nameLabel) nameLabel.string = this.players[i].name;
            player.name = "Player_" + i;
            player.teamId = teamInfo[i];
            player.isTeammate = player.teamId === this.mTeamId;
            player.isPlayer = true;
            player.objType = 1; // 0: sundries; 1: player; 2: bot; 3: fire
            player.playerNo = i;
            this.node.addChild(player);
            player.x = (1 + i) * horiSpan;
            player.y = player.isTeammate ? player.height : this.node.height - player.height;
            this.players[i].gameObject = player;
        }

        console.log('Assign team:', this.players);
        Bgs.CloudAction('OnTeamInfoGet');
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Game.js.map
        