(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Room/PlayerItem.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'a0ecbZwyUBPd4EAl+9WcoA8', 'PlayerItem', __filename);
// scripts/Room/PlayerItem.js

'use strict';

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

var PlayerStatus_NoBody = 0,
    // 该位置上尚无玩家
PlayerStatus_Waitting = 1,
    // 该位置上有玩家，在等待中，尚未准备
PlayerStatus_Ready = 2,
    // 该位置上有玩家，已经准备了
PlayerStatus_Playing = 3,
    // 该位置上有玩家，已经在游戏中
PlayerStatus_GameOut = 4,
    // 该位置上有玩家，已经在游戏中被淘汰
PlayerStatus_Offline = 5; // 该位置上有玩家，已经在游戏中，但是掉线了

cc.Class({
    extends: cc.Component,

    properties: {

        Label: {
            default: null,
            type: cc.Label
        }

        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},
    setUserInfo: function setUserInfo(no, name, status) {
        if (!name) name = '';
        switch (status) {
            case PlayerStatus_NoBody:
                status = '无人';
                break;
            case PlayerStatus_Waitting:
                status = '未准备';
                break;
            case PlayerStatus_Ready:
                status = '已准备';
                break;
            case PlayerStatus_Playing:
                status = '游戏中';
                break;
            case PlayerStatus_GameOut:
                status = '已淘汰';
                break;
            case PlayerStatus_Offline:
                status = '已掉线';
                break;
        }
        this.Label.string = no + 1 + '号   ' + name + '   状态:' + status;
    }

    // update (dt) {},

});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=PlayerItem.js.map
        