package cn.bmob.gamesdk.server.custom;

import cn.bmob.gamesdk.server.api.BmobGameSDKHook;
import cn.bmob.gamesdk.server.api.PlayerBase;

public class Player extends PlayerBase {

	public int teamId = 0;
	private boolean isDead = false;
	private boolean isLoadOk = false, isTeamClear = false;
	private long[] dieReports;

	// 不重复下发怪物死亡事件

	@BmobGameSDKHook
	public native void setIsDead(boolean isDead);

	@Override
	public void onGameStart() {
		dieReports = new long[room.playerCount];
		isLoadOk = false;
		isDead = false;
		setIsDead(isDead);
		syncToClient();
	}

	@BmobGameSDKHook
	public strictfp void onAction_OnGameLoad(byte[] bs) {
		// 加载好了游戏场景，并且收到了队伍安排
		this.isLoadOk = true;
		// 检查是否全部都准备好了
		for (Player p : roommates)
			if (!p.isLoadOk)
				return;
		// 让房间真正运作起来
		room.assignTeam();
	}

	@BmobGameSDKHook
	public strictfp void onAction_OnTeamInfoGet(byte[] bs) {
		// 加载好了游戏场景，并且收到了队伍安排
		this.isTeamClear = true;
		// 检查是否全部都准备好了
		for (Player p : roommates)
			if (!p.isTeamClear)
				return;
		// 让房间真正运作起来
		room.reallyPlaying();
	}

	// 有玩家上报，发现某一个玩家死亡
	@BmobGameSDKHook
	public strictfp void onAction_PlayerCrash(byte[] infos) {
		if (room.isNotReallyStart || isDead)// 已经死亡的玩家，汇报不予采信
			return;

		// 注意，如果是敌机碰到自己，会发送两条，一条说自己被对方撞死，另一条是对方被自己撞死，这个时候都当作是汇报自己死亡

		// 0: 坠机对象的no，用byte表达的话，最多兼容256人大房间
		// 1: 伤害者类型(0: 敌方玩家(直接碰撞); 1: 敌方炮弹; 2: 敌方Bot)
		// 2: 如果是敌方玩家直接碰撞，那么对方的no是什么
		int dieNo = (int) infos[0];
		if (dieNo < 0 || dieNo > room.playerCount) {// 如果是128人以上的房间，dieNo可能是-127~-1，要考虑兼容
			kick(); // 不合法的上报，踢出玩家
			return;
		}
		int murdererNo = -1;
		if (infos[1] == 0) {
			murdererNo = (int) infos[2];
			if (murdererNo < 0 || murdererNo > room.playerCount) {
				kick(); // 不合法的上报，踢出玩家
				return;
			}
		}

		if (dieNo == no || murdererNo == no) {
			// 给另外一个玩家添加一个死亡报告
			if (dieNo == no) {
				if (murdererNo != -1)
					roommates[murdererNo].reportDie(this);
			} else
				roommates[dieNo].reportDie(this);

			die();// 本玩家死亡
		} else { // 观察其它玩家的死亡
			roommates[dieNo].reportDie(this);
		}
	}

	void reportDie(Player reporter) {
		if (room.isNotReallyStart || isDead) // 死猪不怕开水烫
			return;
		long curTime = getTime();
		dieReports[reporter.no] = curTime;
		int dieCount = 0;
		long reportExpired = curTime - 2000;
		for (long time : dieReports)
			if (time > reportExpired)
				dieCount++;
		if (dieCount < room.confidenceInterval)
			return;
		die();
	}

	void die() {
		isDead = true;
		setIsDead(isDead);
		syncToClient();
		sendToAll(new byte[] { Room.NotifyType_PlayerCrash, (byte) no });

	
		int[] teamAliveCounts = new int[] { 0, 0 };
		String msg = String.format("Player[%d][%s] die\n", no, getUserId());
		for (Player p : roommates) {
			if (p.isDead) {
				msg += p.no + " is dead, team " + p.teamId + "\n";
				continue;
			}
			teamAliveCounts[p.teamId]++;
			msg += p.no + " is alive, team " + p.teamId + "\n";
		}
		msg += String.format("team_0 has alive[%d] and team_1 is [%d]", no,
				teamAliveCounts[0], teamAliveCounts[1]);

		cn.bmob.gamesdk.server.Main.l(msg);
		if (teamAliveCounts[0] == 0 || teamAliveCounts[1] == 0) { // 有一个队没人了
			// 准备发送GameOver, 0:平局，1:胜利，2:失败
			byte[] toTeam0 = new byte[] { Room.NotifyType_GameOver, 0 }, //
			toTeam1 = new byte[] { Room.NotifyType_GameOver, 0 };
			if (teamAliveCounts[0] == teamAliveCounts[1]) {// 都没人了

			} else if (teamAliveCounts[0] == 0) { // 队伍1胜利
				toTeam0[1] = 2;
				toTeam1[1] = 1;
			} else {
				toTeam0[1] = 1;
				toTeam1[1] = 2;
			}
			for (Player p : roommates)
				p.send(p.teamId == 0 ? toTeam0 : toTeam1);
			room.gameOver(); // 游戏结束
		}
	}

	// 有玩家上报，怪物死亡
	@BmobGameSDKHook
	public strictfp void onAction_BotDie(byte[] infos) { // 暂时放怪物名
		if (room.isNotReallyStart)
			return;
		// cn.bmob.gamesdk.server.Main.l("BotDie: (" +
		// java.util.Arrays.toString(infos) + ") : " + infos.length);
		if (room.isBotDieNow(new String(infos))) {// 不重复的
			byte[] sendInfos = new byte[1 + infos.length];
			sendInfos[0] = Room.NotifyType_BotDie;
			arraycopy(infos, 0, sendInfos, 1, infos.length);
			sendToAll(sendInfos);
		}
	}

	// 游戏中掉线，当作死亡
	@Override
	public void onOffline() {
		if (room.isNotReallyStart)
			return;
		die();
	}

	// 游戏中离开房间，当作死亡
	@Override
	public void onLeave() {
		if (room.isNotReallyStart)
			return;
		die();
	}

}
