"use strict";
cc._RF.push(module, 'fb57crf0LRD14ly3oMdcEtE', 'Fire');
// scripts/Game/Fire.js

"use strict";

var MovableObj = require("MovableObj");

cc.Class({
    extends: MovableObj,

    properties: {},

    onSubLoad: function onSubLoad() {
        var size = this.node.parent.width / 20;
        this.node.scaleX = size / (this.node.width * 8);
        this.node.scaleY = size / this.node.height;
    },
    onSubUpdate: function onSubUpdate(dt) {},


    onCollisionEnter: function onCollisionEnter(other, self) {
        console.log('Bullet touch sb');
        this.node.destroy();
        // console.log('Fire onCollisionEnter: ', other, self);
    }

});

cc._RF.pop();