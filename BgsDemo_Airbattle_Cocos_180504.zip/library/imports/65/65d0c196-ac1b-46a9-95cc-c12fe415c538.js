"use strict";
cc._RF.push(module, '65d0cGWrBtGqZXMwS/kFcU4', 'Room');
// scripts/Room/Room.js

'use strict';

var Bgs = require('bgsapi');
var zutils = require('ZwrCocosUtil');

var PlayerStatus_NoBody = 0,
    // 该位置上尚无玩家
PlayerStatus_Waitting = 1,
    // 该位置上有玩家，在等待中，尚未准备
PlayerStatus_Ready = 2,
    // 该位置上有玩家，已经准备了
PlayerStatus_Playing = 3,
    // 该位置上有玩家，已经在游戏中
PlayerStatus_GameOut = 4,
    // 该位置上有玩家，已经在游戏中被淘汰
PlayerStatus_Offline = 5,
    // 该位置上有玩家，已经在游戏中，但是掉线了

PlayerRoomAction_Join = 1,
    PlayerRoomAction_Leave = 2,
    PlayerRoomAction_Offline = 3,
    PlayerRoomAction_Reconn = 4,
    PlayerRoomAction_Ready = 5,
    PlayerRoomAction_Unready = 6,
    PlayerRoomAction_Kicked = 7,
    PlayerRoomAction_GameOver = 8,
    PlayerRoomAction_GameLose = 9,
    RoomAction_Start = 20;

cc.Class({
    extends: cc.Component,

    properties: {
        ItemNode: {
            default: null,
            type: cc.Prefab
        },

        ItemContent: {
            default: null,
            type: cc.Node
        },

        AlertText: {
            default: null,
            type: cc.Label
        }
    },

    doAlert: function doAlert(msg, color) {
        this.AlertText.string = msg;
    },
    onRoomAction: function onRoomAction(action, no, data) {
        console.log('onRoomAction:', arguments);
        if (!no) no = 0;
        var item = this.playerItems[no].data;
        var userId = data.userId;
        if (userId) {
            userId = decodeURIComponent(decodeURIComponent(userId));
            item.userId = userId;
            userId = "'" + userId + "'";
        } else userId = '';

        switch (action) {
            case PlayerRoomAction_Join:
                item.status = PlayerStatus_Waitting;
                this.doAlert('玩家' + userId + '已经加入房间');
                break;
            case PlayerRoomAction_Leave:
                item.status = PlayerStatus_NoBody;
                this.doAlert('玩家' + userId + '已经离开房间');
                item.userId = '';
                break;
            case PlayerRoomAction_Offline:
                item.status = PlayerStatus_Offline;
                this.doAlert('玩家' + userId + '已经掉线');
                break;
            case PlayerRoomAction_Reconn:
                item.status = PlayerStatus_Playing;
                this.doAlert('玩家' + userId + '已经重新上线');
                break;
            case PlayerRoomAction_Ready:
                item.status = PlayerStatus_Ready;
                this.doAlert('玩家' + userId + '已准备');
                break;
            case PlayerRoomAction_Unready:
                item.status = PlayerStatus_Waitting;
                this.doAlert('玩家' + userId + '已取消准备');
                break;
            case PlayerRoomAction_Kicked:
                item.status = PlayerStatus_NoBody;
                this.doAlert('玩家' + userId + '已被请出房间');
                item.userId = '';
                break;
            case RoomAction_Start:
                this.doStartGame(data);
                break;
        }

        this.playerItems[no].script.setUserInfo(no, item.userId, item.status);
    },
    doStartGame: function doStartGame(data) {
        var playerCount = this.playerCount,
            no = this.mNo,
            startTime = data.startTime,
            nowTime = data.nowTime;

        console.log('客户端时间领先服务器：' + (new Date().getTime() - nowTime) + 'ms');

        if (playerCount > 1 && no > -1 && startTime > 0) {
            var names = [];
            for (var i = 0; i < playerCount; i++) {
                names.push(this.playerItems[i].data.userId);
            }Bgs.set('playerCount', playerCount).set('mNo', no).set('startTime', startTime).set('players', names);
            this.doAlert('开始进入游戏');
            this.isStartingGame = true;

            zutils.IsGameDebug = false;
            console.log('IsGameDebug = ' + zutils.IsGameDebug);
            cc.director.loadScene('Game');
        } else this.doAlert('数据异常');
    },
    onOffline: function onOffline() {
        console.log('onOffline:', arguments);
        this.doAlert('断开连接');
        setTimeout(this.doQuit.bind(this), 3000);
    },
    getValue: function getValue(key) {
        return cc.sys.localStorage.getItem(key);
    },
    doReady: function doReady() {
        if (this.isJoined) Bgs.ReadyAtRoom();else this.doAlert('尚未进入房间');
    },
    doQuit: function doQuit() {
        if (this.isJoined) {
            console.log('Was joined, quit room!');
            Bgs.QuitRoom();
        }
        cc.director.loadScene('Lobby');
    },
    onLoad: function onLoad() {
        zutils.FixSize(this.node);

        this.isJoined = false;
        this.isStartingGame = false;
        this.doAlert('正在加入房间');
        this.mRoomActListener = this.onRoomAction.bind(this);
        this.mOfflineListener = this.onOffline.bind(this);
        Bgs.RegistRoomActListener(this.mRoomActListener);
        Bgs.RegistOfflineListener(this.mOfflineListener);

        Bgs.JoinRoom(this.getValue('roomId'), this.getValue('joinKey'), encodeURIComponent(encodeURIComponent(this.getValue('userId'))), this.getValue('seatKey'), function (isOK, data) {
            if (isOK) {
                this.doAlert('加入房间成功');

                var playerCount = data.playerCount,
                    no = data.no,
                    isPlaying = data.isPlaying,
                    players = data.players;

                console.log('players:', players);

                if (data.seatKey) Bgs.set('seatKey', data.seatKey);

                this.playerCount = playerCount;
                this.mNo = no;

                var itemHeight = 0;
                var items = [];
                for (var i = 0; i < playerCount; i++) {
                    var item = cc.instantiate(this.ItemNode);
                    players[i].userId = decodeURIComponent(decodeURIComponent(players[i].userId));
                    items.push({
                        script: item.getComponent('PlayerItem'),
                        data: players[i]
                    });
                    items[i].script.setUserInfo(i, players[i].userId, players[i].status);
                    itemHeight += item.height;
                    this.ItemContent.addChild(item);
                }
                this.playerItems = items;

                var contentLayout = this.ItemContent.getComponent(cc.Layout);
                var height = contentLayout.paddingTop + contentLayout.paddingBottom;
                height += itemHeight + (playerCount - 1) * contentLayout.spacingY;
                this.ItemContent.height = height;

                this.isJoined = true;

                if (isPlaying) {
                    if (players[no].status == PlayerStatus_GameOut) this.doAlert('已被淘汰，请等待');else this.doStartGame(data);
                }
            } else {
                this.doAlert('加入房间失败');
                setTimeout(this.doQuit.bind(this), 3000);
            }
            console.log('Join over:' + isOK, data);
        }.bind(this));
    },
    onDestroy: function onDestroy() {
        Bgs.UnregistRoomActListener(this.mRoomActListener);
        Bgs.UnregistOfflineListener(this.mOfflineListener);
        this.mRoomActListener = null;
        this.mOfflineListener = null;
        this.playerItems = null;
        if (!this.isStartingGame) Bgs.QuitRoom();
    }
});

cc._RF.pop();