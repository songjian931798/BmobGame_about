"use strict";
cc._RF.push(module, '8fe4fqSXkdNLZ8ql1hL70d6', 'ZwrCocosUtil');
// scripts/ZwrCocosUtil.js

"use strict";

module.exports = {
    IsGameDebug: true,
    FixSize: function FixSize(node) {
        node.scaleX = node.parent.width / node.width;
        node.scaleY = node.parent.height / node.height;
        node.x = -node.parent.width / 2;
        node.y = -node.parent.height / 2;
    }
};

cc._RF.pop();