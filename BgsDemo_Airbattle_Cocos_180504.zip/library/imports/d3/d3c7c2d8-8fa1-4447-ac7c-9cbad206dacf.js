"use strict";
cc._RF.push(module, 'd3c7cLYj6FER6x8nLrSBtrP', 'bgsapi');
// bmobgamesdk/bgsapi.js

"use strict";

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var HttpHost = "https://gameapi.bmob.cn";
var Version = 1;

var PlayerStatus_NoBody = 0,
    // 该位置上尚无玩家
PlayerStatus_Waitting = 1,
    // 该位置上有玩家，在等待中，尚未准备
PlayerStatus_Ready = 2,
    // 该位置上有玩家，已经准备了
PlayerStatus_Playing = 3,
    // 该位置上有玩家，已经在游戏中
PlayerStatus_GameOut = 4,
    // 该位置上有玩家，已经在游戏中被淘汰
PlayerStatus_Offline = 5,
    // 该位置上有玩家，已经在游戏中，但是掉线了

PlayerRoomAction_Join = 1,
    PlayerRoomAction_Leave = 2,
    PlayerRoomAction_Offline = 3,
    PlayerRoomAction_Reconn = 4,
    PlayerRoomAction_Ready = 5,
    PlayerRoomAction_Unready = 6,
    PlayerRoomAction_Kicked = 7,
    PlayerRoomAction_GameOver = 8,
    PlayerRoomAction_GameLose = 9,
    RoomAction_Start = 20;

var ___fp = [0x0080, 0x0040, 0x0020, 0x0010, 0x0008, 0x0004, 0x0002, 0x0001];
var cache = {};

var ___ps = function ___ps(n) {
    var u = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "#Unknown";

    _classCallCheck(this, ___ps);

    this._n = n;
    this._u = u;
    this._s = {};
};

var ___bd = new DataView(new ArrayBuffer((1 << 5) - (1 << 3)));
var ___bd_gb = ___bd.getUint8.bind(___bd),
    ___bd_sb = ___bd.setUint8.bind(___bd);

function __ge(val, bs, off) {
    ___bd.setFloat32(0, val, false);
    bs[off] = ___bd_gb(0);
    bs[off + 1] = ___bd_gb(1);
    bs[off + 2] = ___bd_gb(2);
    bs[off + 3] = ___bd_gb(3);
}

function __fe(val, bs, off) {
    ___bd.setFloat64(4, val, false);
    bs[off] = ___bd_gb(4);
    bs[off + 1] = ___bd_gb(5);
    bs[off + 2] = ___bd_gb(6);
    bs[off + 3] = ___bd_gb(7);
    bs[off + 4] = ___bd_gb(8);
    bs[off + 5] = ___bd_gb(9);
    bs[off + 6] = ___bd_gb(10);
    bs[off + 7] = ___bd_gb(11);
}

function __gt(bs, off) {
    ___bd_sb(12, bs[off] & 0xff);
    ___bd_sb(13, bs[off + 1] & 0xff);
    ___bd_sb(14, bs[off + 2] & 0xff);
    ___bd_sb(15, bs[off + 3] & 0xff);
    return ___bd.getFloat32(12);
}

function __ft(bs, off) {
    ___bd_sb(16, bs[off] & 0xff);
    ___bd_sb(17, bs[off + 1] & 0xff);
    ___bd_sb(18, bs[off + 2] & 0xff);
    ___bd_sb(19, bs[off + 3] & 0xff);
    ___bd_sb(20, bs[off + 4] & 0xff);
    ___bd_sb(21, bs[off + 5] & 0xff);
    ___bd_sb(22, bs[off + 6] & 0xff);
    ___bd_sb(23, bs[off + 7] & 0xff);
    return ___bd.getFloat64(16);
}

var ___pa = function () {
    function ___pa(ind, name) {
        _classCallCheck(this, ___pa);

        this._i = ind;
        this._n = name;
        this._c = 0;
        this._b = 0;
        this._m = 0;
        this._t = 0;
        this._d = false;
        this._x = false;
    }

    _createClass(___pa, [{
        key: "i",
        value: function i(t, b, o) {
            var v = null;
            var i = void 0;
            switch (this._t) {
                case 0x0000:
                    v = b[o] == 1;
                    break;
                case 0x0080:
                    var zs = new Array(this._c);
                    for (i = 0; i < this._c; i++) {
                        zs[i] = (b[o + (i >> 3)] & ___fp[i % 8]) != 0;
                    }v = zs;
                    break;
                case 0x0003:
                    var s = 0;
                    for (i = o; i < o + this._b; i++) {
                        s = s << 8 | b[i];
                    }v = s;
                    break;
                case 0x0083:
                    var ints = new Array(this._c);
                    var itemCount = this._b / this._c;
                    for (i = 0; i < this._c; i++) {
                        for (var j = 0; j < itemCount; j++) {
                            ints[i] = ints[i] << 8 | b[o + j];
                        }o += itemCount;
                    }
                    v = ints;
                    break;
                case 0x0002:
                    v = __gt(b, o);
                    break;
                case 0x0082:
                    var fs = new Array(this._c);
                    for (i = 0; i < this._c; i++) {
                        fs[i] = __gt(b, o);
                        o += 4;
                    }
                    v = fs;
                    break;
                case 0x0001:
                    v = __ft(b, o);
                    break;
                case 0x0081:
                    var ds = new Array(this._c);
                    for (i = 0; i < this._c; i++) {
                        ds[i] = __ft(b, o);
                        o += 8;
                    }
                    v = ds;
                    break;
            }
            if (v != null) {
                t[this._n] = v;
                return true;
            }
            return false;
        }
    }]);

    return ___pa;
}();

var WssUrl = '';
var BGSId = '';
var __at = [],
    __pl = [],
    __ae = {},
    __lu = [],
    __ec = -1,
    __pc = -1,
    __os = -1,
    __ms = -1,
    __mp = -1,
    __mb = -1,
    __ic = false,
    __ir = false,
    __et = null,
    __ai = {},
    __ah = [0x03, 0, 0, 0],
    __mr = [],
    __1s = null,
    __2p = 0,
    __mn = -1;
var __1o, __1r, __1j, __hr;
var __re = function __re(bs) {
    if (__1s) __hr(bs);else __mr.push(bs);
};
var __mh = __re;

function __bc(n) {
    return n < 0x100 ? 1 : n < 0x10000 ? 2 : parseInt(Math.log(n) / Math.log(0x100)) + 1;
}

function __ia(o) {
    return Object.prototype.toString.call(o) == '[object Array]';
}

function __if(f) {
    return f && typeof f === 'function';
}

var _Model = function () {
    function _Model() {
        _classCallCheck(this, _Model);

        this.WriteFloat = __ge;
        this.WriteDouble = __fe;
        this.ReadFloat = __gt;
        this.ReadDouble = __ft;
        this.Version = Version;
        __hr = this.__hr1.bind(this);
    }

    _createClass(_Model, [{
        key: "__hr1",
        value: function __hr1(body) {
            try {
                switch (body.shift()) {
                    case 0x03:
                        {
                            var d = JSON.parse(this.bytesToString(body, 0, body.length));__1s[0](d.action, d.no, d);
                            break;
                        }
                    case 0x05:
                        {
                            if (__2p < 2 || __os < 0) return;
                            var _7m = false;
                            var _7c = {};
                            var _7s = __2p + 7 >> 3;
                            var _7x = new Array(__2p);
                            var _7o1 = 0,
                                _7o2 = _7s;
                            var b = void 0,
                                _7i = void 0,
                                _7i1 = void 0;
                            var _7ab = void 0;
                            for (; _7o1 < _7s; _7o1++) {
                                b = body[_7o1];
                                for (_7i = 0; _7i < 8; _7i++) {
                                    if ((b & ___fp[_7i]) != 0) {
                                        _7x[_7o1 << 3 | _7i] = true;
                                        _7o2 += __os;
                                    }
                                }
                            }
                            var _6i = void 0;
                            var _6c = {};
                            for (_7i = 0; _7i < __2p; _7i++) {
                                if (_7x[_7i]) {
                                    _6i = _7i == __mn;
                                    if (!_6i) _6c = {};
                                    for (_7i1 = 0; _7i1 < __ec; _7i1++) {
                                        if ((body[_7o1 + (_7i1 >> 3)] & ___fp[_7i1 % 8]) != 0) {
                                            _7ab = __at[_7i1];
                                            if (_7ab._x) {
                                                if (!_6i || !_7ab._d) {
                                                    if (_7ab.i(__pl[_7i]._s, body, _7o2)) {
                                                        if (_6i) {
                                                            _7m = true;
                                                            _7c[_7ab._n] = true;
                                                        } else _6c[_7ab._n] = true;
                                                    } else return;
                                                }
                                                _7o2 += _7ab._b;
                                            } else return;
                                        }
                                    }
                                    if (!_6i) __1s[2](_7i, _6c, __pl[_7i]._s);
                                    _7o1 += __os;
                                }
                            }
                            if (_7o2 + __ms < body.length) {
                                var _6m = __pl[__mn]._s;
                                var cursorAtP_4 = _7o2,
                                    cursorAtP_5 = _7o2 + __ms;
                                for (_7i1 = 0; _7i1 < __pc; _7i1++) {
                                    if ((body[cursorAtP_4 + (_7i1 >> 3)] & ___fp[_7i1 % 8]) != 0) {
                                        _7m = true;
                                        _7ab = __at[_7i1 + __ec];
                                        _7c[_7ab._n] = true;
                                        if (_7ab._x) return;else {
                                            if (!_7ab.i(_6m, body, cursorAtP_5)) return;
                                            cursorAtP_5 += _7ab._b;
                                        }
                                    }
                                }
                            }
                            if (_7m) __1s[1](_7c, __pl[__mn]._s);
                            break;
                        }
                    case 0x06:
                        {
                            __1s[4](body);
                            break;
                        }
                    case 0x07:
                        {
                            if (__mb > 0) {
                                var no = 0,
                                    cursor = 0;
                                for (var i = 0; i < __mb; i++) {
                                    no = no << 8 | body.shift();
                                }__1s[3](no, body);
                            }
                            break;
                        }
                }
            } catch (e) {
                console.log(e);
            }
        }
    }, {
        key: "__sc",
        value: function __sc(data) {
            __mp = data.maxPlayerCount;
            if (__mp < 2) throw "Error";
            var _6s = data.attrs;
            var _6a = !!_6s ? _6s.length : 0;
            if (!_6a || _6a > 255) throw "Error";
            __mb = __bc(__mp);
            __at = new Array(_6a);
            __lu = new Array(_6a);
            __ae = {};
            var _6e = 0,
                _6p = 0;
            for (var _7d = 0; _7d < _6a; _7d++) {
                var _7t = _6s[_7d];
                var _7ab = new ___pa(_7d, _7t.name.toLowerCase());
                var t = _7t["type"];
                _7ab._t = t.charCodeAt(0) - 98 >> 1 | (t.charCodeAt(t.length - 1) == 93 ? 1 : 0) << 7;
                switch (_7ab._t) {
                    case 0x0000:
                        _7ab._b = 1 << 0;
                        break;
                    case 0x0001:
                        _7ab._b = 1 << 3;
                        break;
                    case 0x0002:
                        _7ab._b = 1 << 2;
                        break;
                    case 0x0003:
                        _7ab._b = __bc(_7t.max);
                        break;
                    case 0x0083:
                        _7ab._b = __bc(_7t.max) * _7t.count;
                        break;
                    case 0x0082:
                        _7ab._b = _7t.count << 2;
                        break;
                    case 0x0081:
                        _7ab._b = _7t.count << 3;
                        break;
                    case 0x0080:
                        _7ab._b = __bc(_7t.count);
                        break;
                }
                _7ab._c = _7t.count;
                _7ab._m = _7t.max;
                _7ab._d = !!_7t.editable;
                _7ab._x = !!_7t["export"];
                __at[_7d] = _7ab;
                if (_7ab._d) __ae[_7ab._n] = _7ab;
                if (_7ab._x) _6e++;else _6p++;
            }
            __ec = _6e;
            __pc = _6p;
            __os = _6e + 7 >> 3;
            __ms = _6p + 7 >> 3;
        }
    }, {
        key: "SendTransferToAllExceptSelf",
        value: function SendTransferToAllExceptSelf(bs) {
            return this.SendBytes([0x07, 2].concat(bs));
        }
    }, {
        key: "RegistOfflineListener",
        value: function RegistOfflineListener(listener) {
            if (__if(listener)) {
                __1o = function __1o() {
                    if (!this.isCalled) {
                        this.isCalled = true;
                        this.origin();
                    }
                };
                __1o.origin = listener;
                __1o = __1o.bind(__1o);
            }
        }
    }, {
        key: "UnregistOfflineListener",
        value: function UnregistOfflineListener(listener) {
            if (__1o && __1o.origin === listener) __1o = null;
        }
    }, {
        key: "RegistRoomActListener",
        value: function RegistRoomActListener(listener) {
            if (__if(listener)) __1r = listener;
        }
    }, {
        key: "UnregistRoomActListener",
        value: function UnregistRoomActListener(listener) {
            if (__1r === listener) __1r = null;
        }
    }, {
        key: "EditMyStatus",
        value: function EditMyStatus(name, value) {
            var abortSame = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;

            var _6as = abortSame;
            if (name && value !== undefined && value !== null) {
                var _7ab = __ae[name.toLowerCase()];
                if (_7ab && _7ab._d) {
                    var offset = 5;
                    var _6b = new Array(offset + _7ab._b);
                    var isOK = false;
                    switch (_7ab._t) {
                        case 0x0000:
                            if (typeof value === 'boolean') {
                                _6b[offset] = value ? 1 : 0;
                                isOK = true;
                            }
                            break;
                        case 0x0080:
                            if (__ia(value)) {
                                var zs = new Array(_7ab._c);
                                for (var i = 0; i < _7ab._c; i++) {
                                    if (zs[i]) _6b[offset + (i >> 3)] |= ___fp[i % 8];
                                }isOK = true;
                            }
                            break;
                        case 0x0003:
                            if (typeof value === 'number') {
                                if (value < _7ab._m) {
                                    for (var j = offset + _7ab._b - 1; j > offset - 1; j--) {
                                        _6b[j] = value & 0xff;
                                        value >>= 8;
                                    }
                                    isOK = true;
                                }
                            }
                            break;
                        case 0x0083:
                            if (__ia(value)) {
                                if (value.length == _7ab._c) {
                                    var _6oc = _7ab._b / _7ab._c;
                                    isOK = true;
                                    for (var vi = 0, vl = _7ab._c; vi < vl; vi++) {
                                        var v = value[vi];
                                        if (v < _7ab._m) {
                                            for (var _j = offset + _6oc - 1; _j > offset - 1; _j--) {
                                                _6b[_j] = v & 0xff;
                                                v >>= 8;
                                            }
                                        } else {
                                            isOK = false;
                                            break;
                                        }
                                        offset += _6oc;
                                    }
                                }
                            }
                            break;
                        case 0x0002:
                            if (typeof value === 'number') {
                                __ge(value, _6b, offset);
                                isOK = true;
                            }
                            break;
                        case 0x0082:
                            if (__ia(value) && value.length == _7ab._c) {
                                for (var fi = 0, fl = _7ab._c; fi < fl; fi++) {
                                    __ge(f, _6b, offset + (fi << 2));
                                }isOK = true;
                            }
                            break;
                        case 0x0001:
                            if (typeof value === 'number') {
                                __fe(value, _6b, offset);
                                isOK = true;
                            }
                            break;
                        case 0x0081:
                            if (__ia(value) && value.length == _7ab._c) {
                                for (var _fi = 0, _fl = _7ab._c; _fi < _fl; _fi++) {
                                    __fe(f, _6b, offset + (_fi << 3));
                                }isOK = true;
                            }
                            break;
                    }
                    if (isOK) {
                        _6b[0] = 0x05;
                        _6b[4] = _7ab._i;
                        if (_6as && __lu != null) {
                            var _6lu = __lu[_7ab._i];
                            if (_6lu && _6b.length == _6lu.length) {
                                var _6is = true;
                                for (var _i = 5, l = _6b.length; _i < l; _i++) {
                                    if (_6b[_i] != _6lu[_i]) {
                                        _6is = false;
                                        break;
                                    }
                                }if (_6is) return 1;
                            }
                        }
                        if (this.SendBytes(_6b)) {
                            if (_6as) __lu[_7ab._i] = _6b;
                            return 0;
                        } else return -1;
                    }
                }
            }
            return -1;
        }
    }, {
        key: "ReadyAtRoom",
        value: function ReadyAtRoom() {
            if (__ir) return this.SendBytes([0x02, 0x05]);
            return false;
        }
    }, {
        key: "SendBytes",
        value: function SendBytes(bs) {
            if (__ic) {
                __et.send(this.__ib(bs));
                return true;
            }
            return false;
        }
    }, {
        key: "QuitRoom",
        value: function QuitRoom() {
            if (__ir) {
                __ir = false;
                if (__ic && __et) {
                    __ic = false;
                    var socket = __et;
                    __et = null;
                    socket.send({
                        data: this.__ib([0x02, 0x02]),
                        complete: function complete() {
                            socket.close();
                        }
                    });
                    return true;
                }
            }
            return false;
        }
    }, {
        key: "CloudAction",
        value: function CloudAction(action, bs) {
            if (action) {
                var id = __ai[action.toLowerCase()];
                if (typeof id == 'number') {
                    if (!bs) bs = [];
                    __ah[3] = id;
                    return this.SendBytes(__ah.concat(bs));
                }
            }
            return false;
        }
    }, {
        key: "JoinRoom",
        value: function JoinRoom(roomId, joinKey, userId, seatKey, listener) {
            this.QuitRoom();
            __mr = [];
            if (__if(listener)) {
                if (WssUrl) __1j = listener;else {
                    listener(false, "请在初始化时输入连接地址");
                    return;
                }
            }
            __et = new WebSocket(WssUrl + '/conn/?rid=' + roomId + '&joinkey=' + joinKey + '&uid=' + userId + '&seatkey=' + seatKey);
            __et.binaryType = 'arraybuffer';
            __et.onmessage = this.__or.bind(this);
            var _6of = function (m) {
                __mr = [];
                if (this == __et) {
                    __ic = false;
                    if (__if(__1o)) __1o();
                }
            }.bind(__et);
            __et.onclose = _6of;
            __et.onerror = _6of;
            __ic = true;
        }
    }, {
        key: "SetGameRuntimeListeners",
        value: function SetGameRuntimeListeners() {
            var __6as = 5;
            if (arguments && arguments.length == __6as) {
                var ___is = new Array(__6as);
                for (var i = 0; i < __6as; i++) {
                    if (__if(arguments[i])) ___is[i] = arguments[i];else return false;
                }__1s = ___is;
                __mh = __hr;
                for (var _i2 = 0, l = __mr.length; _i2 < l; _i2++) {
                    __hr(__mr[_i2]);
                }__mr = [];
                return true;
            }
            return false;
        }
    }, {
        key: "StopGameRuntimeListener",
        value: function StopGameRuntimeListener() {
            __mh = __re;
            __1s = null;
        }
    }, {
        key: "getString",
        value: function getString(buff, off, end) {
            var bs = [];
            for (var i = off; i < end; i++) {
                bs.push(buff.getUint8(i));
            }return String.fromCharCode.apply(null, bs);
        }
    }, {
        key: "bytesToString",
        value: function bytesToString(buff, off, end) {
            var bs = [];
            for (var i = off; i < end; i++) {
                bs.push(buff[i]);
            }return String.fromCharCode.apply(null, bs);
        }
    }, {
        key: "stringToBytes",
        value: function stringToBytes(str) {
            var count = str.length;
            var bs = new Array(count);
            for (var i = 0; i < count; i++) {
                bs[i] = str.charCodeAt(i);
            }return bs;
        }
    }, {
        key: "__ib",
        value: function __ib(r) {
            var l = r.length;
            var buff = new ArrayBuffer(l);
            var uBuff = new Uint8Array(buff);
            for (var i = 0; i < l; i++) {
                uBuff[i] = r[i];
            }return buff;
        }
    }, {
        key: "__or",
        value: function __or(_5m) {
            try {
                _5m = new DataView(_5m.data);
                var _5l = _5m.byteLength;
                if (_5l < 1) return;
                var flag = _5m.getUint8(0);
                var that = this;
                switch (flag) {
                    case 0x01:
                        if (__1j) {
                            var listener = __1j;
                            __1j = null;
                            var co = _5m.getUint8(1);
                            var error = void 0;
                            var bo = this.getString(_5m, 2, _5l);
                            if (co == 0x0c8) try {
                                var ri = JSON.parse(bo);
                                __2p = ri.playerCount;
                                __mn = ri.no;
                                if (typeof __2p == 'number' && __2p > 1 && typeof __mn == 'number' && __mn > -1 && __mn < __2p) {
                                    __pl = new Array(__2p);
                                    for (var pi = 0; pi < __2p; pi++) {
                                        __pl[pi] = new ___ps(pi);
                                    }__ir = true;
                                    listener(true, ri);
                                } else throw 'Error join result';
                            } catch (e) {
                                error = e;
                            } else error = bo + '(' + co + ')';
                            if (error) listener(false, error);
                            that.SendBytes([0x08, 0x02]);
                        }
                        break;
                    case 0x02:
                        if (__1r) {
                            var r = JSON.parse(this.getString(_5m, 1, _5l));
                            __1r(r.action, r.no, r);
                        }
                        break;
                    case 0x08:
                        switch (_5m.getUint8(1)) {
                            case 0x02:
                                __ai = {};
                                if (_5m.getUint8(2) == 1) {
                                    var c = JSON.parse(this.getString(_5m, 3, _5l));
                                    var v = c.actionVersion;
                                    __ah[1] = v >> 8;
                                    __ah[2] = v & 0xff;
                                    var as = c.actions;
                                    for (var i = 0, l = as.length; i < l; i++) {
                                        __ai[as[i]] = i;
                                    }
                                }
                                break;
                            case 0x01:
                                that.__sc(JSON.parse(this.getString(_5m, 2, _5l)));
                                break;
                        }
                        break;
                    default:
                        var bs = new Array(_5l);
                        bs[0] = flag;
                        for (var _i3 = 1; _i3 < _5l; _i3++) {
                            bs[_i3] = _5m.getUint8(_i3);
                        }__mh(bs);
                        break;
                }
            } catch (err) {
                console.log(err);
            }
        }
    }, {
        key: "Init",
        value: function Init(bgsId, wssUrl, callback) {
            if (!__if(callback)) callback = function callback() {};
            BGSId = bgsId;
            if (wssUrl) WssUrl = wssUrl;
            var that = this;
            this.httpReq(HttpHost + "/client/conf?oper=get", "GET", {
                "X-Bgs-Id": BGSId,
                "X-Bgs-Ver": Version + ""
            }, null, function (isOK, data) {
                if (isOK) {
                    if (data.code == 200) {
                        try {
                            that.__sc(data.data);
                            callback(true, 'OK');
                        } catch (e) {
                            console.log(e);
                            callback(false, 'Internal error');
                        }
                    } else callback(false, data.error);
                } else callback(false, data);
            });
        }
    }, {
        key: "get",
        value: function get(key) {
            var defVal = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';

            var val = cache[key];
            if (val || val === 0 || val === '') return val;
            val = cc.sys.localStorage.getItem(key);
            if (val || val === 0 || val === '') cache[key] = val;else val = defVal;
            return val;
        }
    }, {
        key: "set",
        value: function set(key, val) {
            cache[key] = val;
            cc.sys.localStorage.setItem(key, val);
            return this;
        }
    }, {
        key: "httpReq",
        value: function httpReq(path, method, headers, body, listener) {
            try {
                body = JSON.stringify(body);
            } catch (e) {}
            if (!body) body = '';else if (typeof body !== 'string') body += '';
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4) {
                    if (xhr.status == 200) {
                        var response = xhr.responseText;
                        try {
                            response = JSON.parse(response);
                            listener(true, response);
                        } catch (e) {
                            listener(false, 'Parse failed: ' + e);
                        }
                    } else listener(false, 'Status:' + xhr.Status);
                }
            };
            xhr.open(method, path, true);
            if (headers) for (var key in headers) {
                xhr.setRequestHeader(key, headers[key]);
            }xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.send(body);
        }
    }, {
        key: "CreateRoom",
        value: function CreateRoom(userId, playerCount, callback) {
            if (!__if(callback)) callback = function callback() {};
            var that = this;
            this.httpReq(HttpHost + "/client/room?oper=create", "POST", {
                "X-Bgs-Id": BGSId,
                "X-Bgs-Ver": Version + ""
            }, {
                "playerCount": playerCount,
                "userId": userId
            }, function (isOK, data) {
                if (isOK) {
                    if (data.code == 200) {
                        try {
                            callback(true, data.data);
                        } catch (e) {
                            console.log(e);
                            callback(false, e);
                        }
                    } else callback(false, data.error);
                } else callback(false, data);
            });
        }
    }]);

    return _Model;
}();

module.exports = new _Model();

cc._RF.pop();