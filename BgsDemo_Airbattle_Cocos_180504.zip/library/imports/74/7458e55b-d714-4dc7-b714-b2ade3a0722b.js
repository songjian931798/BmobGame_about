"use strict";
cc._RF.push(module, '7458eVb1xRNx7cUsq3joHIr', 'BgsDemo_Lobby');
// scripts/BgsDemo_Lobby.js

'use strict';

var Bgs = require('bgsapi');
var zutils = require('ZwrCocosUtil');

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {

        Nickname: {
            default: null,
            type: cc.EditBox
        },
        PlayerCount: {
            default: null,
            type: cc.EditBox
        },
        RoomId: {
            default: null,
            type: cc.EditBox
        },
        JoinKey: {
            default: null,
            type: cc.EditBox
        },
        Alert: {
            default: null,
            type: cc.Label
        }

        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
    },

    // LIFE-CYCLE CALLBACKS:

    doAlert: function doAlert(msg, color) {
        console.log(msg);
        this.Alert.string = msg;
    },
    onLoad: function onLoad() {
        zutils.FixSize(this.node);

        var that = this;
        this.doAlert('正在初始化BGS...');
        this.isInited = false;
        Bgs.Init('183d136141', 'ws://139.159.220.251:29074', function (ok, res) {
            if (ok) {
                that.isInited = true;
                that.doAlert('初始化BGS成功\n版本号: ' + Bgs.Version);
            } else that.doAlert('初始化BGS失败:\n错误: ' + res);
        });

        var userId = cc.sys.localStorage.getItem('userId');
        if (userId) this.Nickname.string = userId;
        var playerCount = cc.sys.localStorage.getItem('playerCount');
        if (playerCount) this.PlayerCount.string = playerCount;
        var roomId = this.tryGetQueryParams('i');
        if (!roomId) roomId = cc.sys.localStorage.getItem('roomId');
        if (roomId) this.RoomId.string = roomId;
        var joinKey = this.tryGetQueryParams('k');
        if (!joinKey) joinKey = cc.sys.localStorage.getItem('joinKey');
        if (joinKey) this.JoinKey.string = joinKey;
    },
    tryGetQueryParams: function tryGetQueryParams(name) {
        try {
            var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
            var r = window.location.search.substr(1).match(reg);
            if (r != null) return unescape(r[2]);
            return null;
        } catch (e) {}
        return null;
    },
    doCreateRoom: function doCreateRoom() {
        if (!this.isInited) {
            this.doAlert('请等待初始化完毕');
            return;
        }
        var userId = this.Nickname.string;
        if (!userId) {
            this.doAlert("必须输入昵称");
            return;
        }
        var playerCount = this.PlayerCount.string;
        if (!playerCount || !(parseInt(playerCount) > 1)) {
            this.doAlert("房间人数至少为2");
            return;
        }
        cc.sys.localStorage.setItem('userId', userId);
        cc.sys.localStorage.setItem('playerCount', playerCount);

        var that = this;
        Bgs.CreateRoom(encodeURIComponent(userId), parseInt(playerCount), function (isOK, data) {
            console.log('Create result: ' + isOK + ' > ', data);
            if (isOK) {
                var roomInfo = data.roomInfo;
                var roomId = roomInfo.rid + '';
                var joinKey = roomInfo.joinKey;
                that.JoinKey.string = joinKey;
                that.RoomId.string = roomId;

                cc.sys.localStorage.setItem('roomId', roomId);
                cc.sys.localStorage.setItem('joinKey', joinKey);

                that.doAlert('创建成功');
            } else that.doAlert('创建失败:' + data);
        });
    },
    doJoinRoom: function doJoinRoom() {
        if (!this.isInited) {
            this.doAlert('请等待初始化完毕');
            return;
        }
        var userId = this.Nickname.string;
        if (!userId) {
            this.doAlert("必须输入昵称");
            return;
        }
        var roomId = this.RoomId.string;
        if (!roomId || !(parseInt(roomId) > -1)) {
            this.doAlert('必须输入房间号');
            return;
        }
        var joinKey = this.JoinKey.string;
        if (!joinKey) {
            this.doAlert('必须输入房间密码');
            return;
        }

        cc.sys.localStorage.setItem('userId', userId);
        cc.sys.localStorage.setItem('roomId', roomId);
        cc.sys.localStorage.setItem('joinKey', joinKey);

        this.doAlert('准备加入房间');
        cc.director.loadScene('Room');
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();