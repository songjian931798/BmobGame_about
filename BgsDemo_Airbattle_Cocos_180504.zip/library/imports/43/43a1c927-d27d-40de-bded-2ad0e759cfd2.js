"use strict";
cc._RF.push(module, '43a1ckn0n1A3r3tKtDnWc/S', 'OtherPlayer');
// scripts/Game/OtherPlayer.js

'use strict';

var Bgs = require('bgsapi');

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {
        var size = this.node.parent.width / 20;
        this.node.scaleX = size / this.node.width;
        this.node.scaleY = size / this.node.height;
    },


    // update (dt) {},

    planeCrash: function planeCrash(plane, murderer) {

        console.log('Other player is crash, by:', murderer.name, murderer);
        var crashInfo = [plane.playerNo, 1, 0];
        if (murderer.objType == 1) {
            crashInfo[1] = 0;
            crashInfo[2] = murderer.playerNo;
        } else if (murderer.objType == 2) crashInfo[1] = 2;
        Bgs.CloudAction('PlayerCrash', crashInfo);
    },


    onCollisionEnter: function onCollisionEnter(other, self) {
        this.planeCrash(self.node, other.node);
    }

});

cc._RF.pop();