"use strict";
cc._RF.push(module, 'fdaffKF8eFOIZgxW2QN7aYJ', 'HelloGame');
// scripts/HelloGame.js

'use strict';

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {

        starPrefab: {
            default: null,
            type: cc.Prefab
        },

        maxStarDuration: 0,
        minStarDuration: 0,

        ground: {
            default: null,
            type: cc.Node
        },

        player: {
            default: null,
            type: cc.Node
        },

        score: {
            default: null,
            type: cc.Label
        },

        gainAudio: {
            default: null,
            url: cc.AudioClip
        }

        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
    },

    spawnStar: function spawnStar() {
        var star = cc.instantiate(this.starPrefab);
        star.getComponent('Star').game = this;
        this.node.addChild(star);
        star.setPosition(this.getStarRandPosition());
        this.timer = 0;
        this.starDuration = this.minStarDuration + cc.random0To1() * (this.maxStarDuration - this.minStarDuration);
    },

    getStarRandPosition: function getStarRandPosition() {
        var x = cc.randomMinus1To1() * (this.node.width / 2);
        var y = this.groundY + cc.random0To1() * this.player.getComponent('Player').jumpHeight + 50;
        return cc.p(x, y);
    },

    onLoad: function onLoad() {

        this.scoreNum = 0;
        this.groundY = this.ground.y + this.ground.height / 2;

        this.timer = 0;
        this.starDuration = 0;

        this.spawnStar();
    },


    gainScore: function gainScore() {
        this.scoreNum++;
        this.score.string = 'Score: ' + this.scoreNum;
        cc.audioEngine.playEffect(this.gainAudio, false);
    },

    start: function start() {},
    update: function update(dt) {
        if (this.timer > this.starDuration) {
            this.gameOver();
            return;
        }
        this.timer += dt;
    },
    gameOver: function gameOver() {
        this.player.stopAllActions();
        cc.director.loadScene('Scene01');
    }
});

cc._RF.pop();