// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {

        jumpHeight: 0,
        jumpDuration: 0,
        maxMoveSpeed: 0,
        accel: 0,

        canvas: {
            default: null,
            type: cc.Node
        },

        jumpAudio: {
            default: null,
            url: cc.AudioClip
        },

        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
    },

    setJumpAction: function() {
        var jumpUp = cc.moveBy(this.jumpDuration, cc.p(0, this.jumpHeight)).easing(cc.easeCubicActionOut());
        var jumpDown = cc.moveBy(this.jumpDuration, cc.p(0, -this.jumpHeight)).easing(cc.easeCubicActionOut());

        var callback = cc.callFunc(this.playJumpSound, this);
        return cc.repeatForever(cc.sequence(jumpUp, jumpDown, callback));
    },

    playJumpSound: function() {
        cc.audioEngine.playEffect(this.jumpAudio, false);
    },

    setInputControl: function() {
        var that = this;
        // cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, function(event) {
        //     switch (event.keyCode) {
        //         case cc.KEY.a:
        //             that.accLeft = true;
        //             break;
        //         case cc.KEY.d:
        //             that.accRight = true;
        //             break;
        //     }
        // });
        // cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, function(event) {
        //     switch (event.keyCode) {
        //         case cc.KEY.a:
        //             that.accLeft = false;
        //             break;
        //         case cc.KEY.d:
        //             that.accRight = false;
        //             break;
        //     }
        // });

        this.canvas.on(cc.Node.EventType.TOUCH_START, this.touchEvent.bind(this));
        this.canvas.on(cc.Node.EventType.TOUCH_MOVE, this.touchEvent.bind(this));
        this.canvas.on(cc.Node.EventType.TOUCH_END, this.touchEvent.bind(this));
    },

    touchEvent(event) {
        var touchX = event.getTouches()[0].getLocation().x;
        // console.log('Touch at ', touchPos);
        // var touchX = touchPos[0];
        var playerX = this.node.x + this.canvas.width / 2;
        console.log('Player at ' + playerX + ', touch at ' + touchX);
        this.accLeft = touchX < playerX;
        this.accRight = touchX > playerX;
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad() {
        this.jumpAction = this.setJumpAction();
        this.node.runAction(this.jumpAction);

        this.accLeft = false;
        this.accRight = false;
        this.xSpeed = 0;
        this.setInputControl();
    },

    start() {

    },

    update(dt) {
        if (this.accLeft)
            this.xSpeed -= this.accel * dt;
        else if (this.accRight)
            this.xSpeed += this.accel * dt;

        if (this.xSpeed > this.maxMoveSpeed)
            this.xSpeed = this.maxMoveSpeed;
        else if (this.xSpeed < -this.maxMoveSpeed)
            this.xSpeed = -this.maxMoveSpeed;

        var x = this.node.x + this.xSpeed * dt;
        if(x < -this.canvas.width / 2)
            x = -this.canvas.width / 2;
        else if(x > this.canvas.width / 2)
            x = this.canvas.width / 2;

        this.node.x = x;
    },
});