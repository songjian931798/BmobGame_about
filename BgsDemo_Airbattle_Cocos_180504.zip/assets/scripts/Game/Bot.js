var MovableObj = require("MovableObj");
var Bgs = require('bgsapi');

cc.Class({
    extends: MovableObj,

    properties: {
        fire: {
            default: null,
            type: cc.Prefab
        },
        botHp: 2,
        fireSpan: 0.0
    },

    onSubLoad() {
        let size = this.node.parent.width / 20;
        this.node.scaleX = size / this.node.width;
        this.node.scaleY = size / this.node.height;

        if (this.fireSpan > 0 && this.fire != null) {
            this.isOpenFile = true;
            this.nextFire = 0;

            this.spawnY = this.node.height;
            if (this.node.group == 'Enemy') {
                this.spawnY = -this.spawnY;
            }

        } else {
            this.isOpenFile = false;
        }
    },

    botDie(name) {
        console.log('Local bot die:', name);
        Bgs.CloudAction('BotDie', Bgs.stringToBytes(name));
    },

    onCollisionEnter: function(other, self) {
        other = other.node;
        self = self.node;
        // console.log('Bot onCollisionEnter: ', other, self);
        switch (other.objType) {
            case 1:
                this.botDie(self.name);
                break;
            case 2:
                this.botDie(other.name);
                this.botDie(self.name);
                break;
            case 3:
                this.botHp--;
                if (this.botHp == 0)
                    this.botDie(self.name);
                break;
            default:
                console.log('Bot collision:', other.objType, other);
                break;    
        }
    },

    onSubUpdate(dt) {
        if (this.isOpenFile) {
            let curTime = new Date().getTime();
            if (curTime > this.nextFire) {
                this.nextFire = curTime + this.fireSpan;
                let fire = cc.instantiate(this.fire);
                this.node.parent.addChild(fire);
                fire.setPosition(this.node.x, this.node.y + this.spawnY);
            }
        }
    },
});