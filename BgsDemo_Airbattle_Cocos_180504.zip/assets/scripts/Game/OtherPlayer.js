var Bgs = require('bgsapi');

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad() {
        let size = this.node.parent.width / 20;
        this.node.scaleX = size / this.node.width;
        this.node.scaleY = size / this.node.height;
    },

    // update (dt) {},

    planeCrash(plane, murderer) {

        console.log('Other player is crash, by:', murderer.name, murderer);
        let crashInfo = [plane.playerNo, 1, 0];
        if (murderer.objType == 1) {
            crashInfo[1] = 0;
            crashInfo[2] = murderer.playerNo;
        } else if (murderer.objType == 2)
            crashInfo[1] = 2;
        Bgs.CloudAction('PlayerCrash', crashInfo);
    },

    onCollisionEnter: function(other, self) {
        this.planeCrash(self.node, other.node);
    },

});