var MovableObj = cc.Class({
    extends: cc.Component,

    properties: {
        crossYCostMillSec: 0.0
    },

    onLoad() {
        let w = this.node.parent.width,
            h = this.node.parent.height;

        if (this.crossYCostMillSec == 0)
            this.speed = 0;
        else
            this.speed = 1000 * h / this.crossYCostMillSec;

        this.xMin = -w / 4;
        this.yMin = -h / 4;
        this.xMax = w + w / 4;
        this.yMax = h + h / 4;

        // console.log(this.name + ' > speed = ' + this.speed);

        this.onSubLoad();
    },

    update(dt) {
        let y = dt * this.speed + this.node.y;
        if (y < this.yMin || y > this.yMax) {
            // console.log('destroy!', this);
            this.node.destroy();
            return;
        }
        let x = this.node.x;
        if(x < this.xMin || x > this.xMax){
            this.node.destroy();
            return;
        }
        this.node.y = y;
        this.onSubUpdate(dt);
    },

});

module.exports = MovableObj;