var MovableObj = require("MovableObj");

cc.Class({
    extends: MovableObj,

    properties: {
    },

    onSubLoad () {
        let size = this.node.parent.width / 20;
        this.node.scaleX = size / (this.node.width * 8);
        this.node.scaleY = size / this.node.height;
    },

    onSubUpdate(dt){},

    onCollisionEnter: function(other, self) {
        console.log('Bullet touch sb');
        this.node.destroy();
        // console.log('Fire onCollisionEnter: ', other, self);
    },

});
