module.exports = {
    IsGameDebug: true,
    FixSize: function(node) {
        node.scaleX = node.parent.width / node.width;
        node.scaleY = node.parent.height / node.height;
        node.x = -node.parent.width / 2;
        node.y = -node.parent.height / 2;
    }
};