import './js/libs/weapp-adapter'
import './js/libs/symbol'
import Main from './js/main'
window.main = new Main()