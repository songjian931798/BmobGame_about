import Sprite from '../base/sprite'

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

export default class UIButton extends Sprite {
	constructor(ctx, src, width, height, x, y, clickListener, span) {
		console.log('Btn x = ' + x + ' y = ' + y + ' w = ' + width + ' h = ' + height);
		super(src, width, height, x, y);
		this.ctx = ctx;
		if (!clickListener || typeof(clickListener) !== 'function')
			clickListener = function() {}
		this.listener = clickListener;
		if (span > 0)
			this.timeSpan = span;
		else
			this.timeSpan = 0;
		this.isTouching = false;
		this.nextTime = 0;
	}

	onTouchEvent(x, y, a) {
		if (a != 2 && this.visible && (this.isTouching === (a != 1)))
			if (x > this.x && y > this.y && x < this.x + this.width && y < this.y + this.height) {
				if (a == 1)
					this.isTouching = true;
				else {
					if (this.timeSpan == 0) {
						this.isTouching = false;
						this.listener();
					} else {
						let nowTime = performance.now()
						if (nowTime > this.nextTime) {
							this.nextTime = nowTime + this.timeSpan;
							this.isTouching = false;
							this.listener();
						}
					}
				}
			}
	}

}