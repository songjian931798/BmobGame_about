import Sprite from '../base/sprite'

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

const BG_IMG_SRC = 'images/bg.jpg'
  // const BG_WIDTH     = 512
  // const BG_HEIGHT    = 512

/**
 * 游戏背景类
 * 提供update和render函数实现无限滚动的背景功能
 */
export default class BackGround extends Sprite {
  constructor(ctx) {
    // super(BG_IMG_SRC, BG_WIDTH, BG_HEIGHT)
    super(BG_IMG_SRC, screenWidth, screenHeight)

    // this.render(ctx)
    this.ctx = ctx;

    this.left = 0
    this.top = 0
  }

  update(x, y) {
    this.left += x;
    this.top += y;

    if (this.left < 0)
      this.left = screenWidth + this.left;
    else if (this.left > screenWidth)
      this.left -= screenWidth;

    if (this.top < 0)
      this.top = screenHeight + this.top;
    else if (this.top > screenHeight)
      this.top -= screenHeight;
  }

  // 绘制9张图片
  render() {
    // for (let x = -1; x < 2; x++)
    //   for (let y = -1; y < 2; y++)
    //     this.ctx.drawImage(this.img, x * this.width - this.left, y * this.height - this.top, this.width, this.height);

    this.ctx.drawImage(this.img, - this.left, - this.top, this.width, this.height);
  }

  // /**
  //  * 背景图重绘函数
  //  * 绘制两张图片，两张图片大小和屏幕一致
  //  * 第一张漏出高度为top部分，其余的隐藏在屏幕上面
  //  * 第二张补全除了top高度之外的部分，其余的隐藏在屏幕下面
  //  */
  // render(ctx) {
  //   ctx.drawImage(
  //     this.img,
  //     0,
  //     0,
  //     this.width,
  //     this.height,
  //     0,
  //     -screenHeight + this.top,
  //     screenWidth,
  //     screenHeight
  //   )

  //   ctx.drawImage(
  //     this.img,
  //     0,
  //     0,
  //     this.width,
  //     this.height,
  //     0,
  //     this.top,
  //     screenWidth,
  //     screenHeight
  //   )
  // }
}