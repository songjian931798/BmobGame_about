let instance

const shortBuffSize = 18;

/**
 * 统一的音效管理器
 */
export default class Music {
  constructor() {
    if (instance)
      return instance

    instance = this

    this.longVoices = [];
    this.shortVoices = [];

    // this.id_Fire_SR = this.createShort('audio/fire_sr.mp3');
    // this.id_Move_Self = this.createLong('audio/footstep_self.mp3');

    // this.gunFires = [];
    // this.gunFireInd = 0;
    // for (let i = 0; i < gunFireBuffCount; i++) {
    //   let gunFire = wx.createInnerAudioContext();
    //   gunFire.src = 'audio/fire_sr.mp3';
    //   this.gunFires.push(gunFire);
    // }

    // this.bgmAudio = new Audio()
    // this.bgmAudio.loop = true
    // this.bgmAudio.src  = 'audio/bgm.mp3'

    // this.shootAudio     = new Audio()
    // this.shootAudio.src = 'audio/bullet.mp3'

    // this.boomAudio     = new Audio()
    // this.boomAudio.src = 'audio/boom.mp3'

    // this.playBgm()
  }

  destroyAll() {
    for (let i = 0, l = this.longVoices.length; i < l; i++)
      this.longVoices[i][1].destroy();
    for (let i = 0, l = this.shortVoices.length; i < l; i++)
      for (let j = 0; j < shortBuffSize; j++)
        this.shortVoices[i][1][j].destroy();
    this.longVoices = [];
    this.shortVoices = [];
  }

  playLong(id, volume) {
    let obj = this.longVoices[id];
    if (volume)
      obj[1].volume = volume;
    if (!obj[0]) {
      obj[0] = true;
      obj[1].play();
    }
  }

  stopLong(id) {
    let obj = this.longVoices[id];
    if (obj[0]) {
      obj[0] = false;
      obj[1].pause();
    }
  }

  createLong(src) {
    let audio = wx.createInnerAudioContext();
    audio.src = src;
    audio.loop = true;
    let id = this.longVoices.length;
    this.longVoices.push([false, audio]);
    return id;
  }

  createShort(src) {
    let audioes = [];
    let audio;
    for (let i = 0; i < shortBuffSize; i++) {
      audio = wx.createInnerAudioContext();
      audio.src = src;
      audioes.push(audio);
    }
    let id = this.shortVoices.length;
    this.shortVoices.push([0, audioes]);
    return id;
  }

  // startMoving() {
  //   if (!this.isMoving) {
  //     this.isMoving = true;
  //     this.selfSootstep.play();
  //   }
  // }

  // stopMoving() {
  //   if (this.isMoving) {
  //     this.isMoving = false;
  //     this.selfSootstep.pause();
  //   }
  // }

  playShortLoudly(id) {
    let obj = this.shortVoices[id];
    let ind = obj[0];
    obj[1][ind].play();
    ind++;
    if (ind < shortBuffSize)
      obj[0] = ind;
    else
      obj[0] = 0;
  }

  playShort(id, volume) {
    let obj = this.shortVoices[id];
    let ind = obj[0];
    obj[1][ind].volume = volume;
    obj[1][ind].play();
    ind++;
    if (ind < shortBuffSize)
      obj[0] = ind;
    else
      obj[0] = 0;
  }

  fire() {
    this.playShort(this.id_Fire_SR);
  }

  // playBgm() {
  //   this.bgmAudio.play()
  // }

  // playShoot() {
  //   this.shootAudio.currentTime = 0
  //   this.shootAudio.play()
  // }

  // playExplosion() {
  //   this.boomAudio.currentTime = 0
  //   this.boomAudio.play()
  // }
}