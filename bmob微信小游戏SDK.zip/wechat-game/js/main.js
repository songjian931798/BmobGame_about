import Splash from './scenes/splash'
import Lobby from './scenes/lobby'
import Room from './scenes/room'
import Game from './scenes/game'

var ctx = canvas.getContext('2d')
window.ctx = ctx;

/**
 * 游戏主函数
 */
export default class Main {
    constructor() {
        this.sceneArr = [new Splash(), new Lobby(), new Room(), new Game()];
        let sceneMap = {};
        for (var i = 0; i < this.sceneArr.length; i++) {
            let s = this.sceneArr[i];
            s.sceneManager = this.loadScene.bind(this);
            s.ctx = ctx;
            sceneMap[i + ""] = s;
            sceneMap[i] = s;
            sceneMap[s.name] = s;
            sceneMap[s.name.toLowerCase()] = s;
        }
        this.sceneMap = sceneMap;

        this.currentScene = null;

        let that = this;
        canvas.addEventListener('touchstart', ((e) => {
            // console.log('Touch at ' + x + ',' + y);
            if (that.currentScene) {
                let point = e.touches[0];
                let x = point.clientX,
                    y = point.clientY;
                that.currentScene.dispatchTouch(x, y, 1, e);
            }
        }));
        canvas.addEventListener('touchmove', ((e) => {
            if (that.currentScene) {
                let point = e.touches[0];
                that.currentScene.dispatchTouch(point.clientX, point.clientY, 2, e);
            }
        }));
        canvas.addEventListener('touchend', ((e) => {
            if (that.currentScene) {
                let point = e.changedTouches[0];
                that.currentScene.dispatchTouch(point.clientX, point.clientY, 3, e);
            }
        }));

        this.loopDraw = window.requestAnimationFrame.bind(window, this.onDraw.bind(this), canvas);
        this.loopDraw();

        this.loadScene(0);
        // this.loadScene('game');
    }

    loadScene(name) {
        let nextScene = this.sceneMap[name];
        if (this.currentScene)
            try {
                this.currentScene.destroy();
            } catch (e) {
                console.log(e);
            }
        wx.triggerGC();
        this.currentScene = null;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        try {
            nextScene.start();
        } catch (e) {
            console.log(e);
        }
        this.currentScene = nextScene;
    }

    // 实现游戏帧循环
    onDraw() {
        if (this.currentScene) {
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            {
                ctx.fillStyle = 'black';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
            }

            this.currentScene.update();
        }
        this.loopDraw();
    }
}