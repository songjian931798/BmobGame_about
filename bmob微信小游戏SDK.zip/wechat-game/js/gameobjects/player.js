import Sprite from '../base/sprite'

const PlayerSrc = 'images/player_red.png'
const Width = 60,
  Height = 60;
const WidthHalf = Width / 2,
  HeightHalf = Height / 2;

export default class Player extends Sprite {
  constructor(x, y) {
    super(PlayerSrc, Width, Height, x - WidthHalf, y - HeightHalf);
  }
}