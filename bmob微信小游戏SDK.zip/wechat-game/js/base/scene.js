/**
 * 游戏基础的场景类
 */
export default class Scene {
    constructor(name = "Unknown") {
        this.isActive = false;
        this.name = name;
        this.touchListeners = [];
        this.sprites = [];
        this.sceneManager = function() {
            console.log('No scene manager');
        };
    }

    // 以下三个方法仅能在Main.js调用
    start() {
        this.touchListeners = [];
        this.l('Scene start: ' + this.name);
        this.isActive = true;
        this.resetCtx();
        this.onStart();
    }
    destroy() {
        this.touchListeners = [];
        this.l('Scene destroy: ' + this.name);
        this.isActive = false;
        this.onDestroy();
    }
    update() {
        if (this.isActive)
            try {
                for (let i = 0, l = this.sprites.length; i < l; i++)
                    this.sprites[i].onDraw(this.ctx);
                this.onUpdate();
            } catch (e) {
                console.log(e);
            }
    }
    dispatchTouch(x, y, a, e) {
        try {
            for (let i = 0, l = this.touchListeners.length; i < l; i++)
                if (this.touchListeners[i].onTouchEvent(x, y, a, e))
                    return;
        } catch (e) {
            console.log(e);
        }
        this.onTouchEvent(x, y, a, e);
    }

    loadScene(name) {
        this.sceneManager(name);
    }

    // left, top, width, height, text, fontSize, color
    drawTextAtCenter(x, y, w, h, t, s, c) {
        let ctx = this.ctx;
        ctx.font = s + "px Verdana";
        if (c)
            ctx.fillStyle = c;
        ctx.fillText(t, x + (w - this.ctx.measureText(t).width) / 2, y + s + (h - s) / 2);
    }
    drawTextAtLeft(x, y, t, s, c) {
        let ctx = this.ctx;
        ctx.font = s + "px Verdana";
        if (c)
            ctx.fillStyle = c;
        ctx.fillText(t, x, y + s);
    }

    resetCtx() {
        try{
            let ctx = this.ctx;
            ctx.strokeStyle = '#333333';
            ctx.fillStyle = '#333333';
            ctx.setLineDash([0]);
        }catch(e){
        }
    }

    l(obj) {
        console.log(obj);
    }

    // 以下三个方法仅能在本文件上面调用，其它地方只能继承
    onStart() {}
    onDestroy() {}
    onUpdate() {}
    onTouchEvent() {}
}