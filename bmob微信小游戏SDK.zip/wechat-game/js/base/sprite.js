/**
 * 游戏基础的精灵类
 */
export default class Sprite {
  constructor(imgSrc = '', width=  0, height = 0, x = 0, y = 0) {
    this.img     = new Image()
    this.img.src = imgSrc

    this.width  = width
    this.height = height

    this.x = x
    this.y = y

    this.visible = true
  }

  /**
   * 将精灵图绘制在canvas上
   */
  onDraw(ctx) {
    if ( !this.visible )
      return

    ctx.drawImage(
      this.img,
      this.x,
      this.y,
      this.width,
      this.height
    )
  }

  /**
   * 简单的碰撞检测定义：
   * 两个可视的矩形框有重叠部分则判定碰撞
   * @param{Sprite} sp: Sptite的实例
   */
  isCollideWith(sp) {
    if (this.visible && sp.visible) {
      let dis = sp.x - this.x;
      if(-sp.width < dis && dis < this.width){
        dis = sp.y - this.y;
        if(-sp.height < dis && dis < this.height)
          return true;
      }
    }
    return false;
  }
}
