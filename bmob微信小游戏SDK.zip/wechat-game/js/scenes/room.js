import Scene from '../base/scene'
import Model from '../bmobgamesdk/bgsapi'

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight
let model = Model.instance;

const
    textSize = 14,
    margin = 20,
    nameMargin = 8;

const
    PlayerRoomAction_Join = 1,
    PlayerRoomAction_Leave = 2,
    PlayerRoomAction_Offline = 3,
    PlayerRoomAction_Reconn = 4,
    PlayerRoomAction_Ready = 5,
    PlayerRoomAction_Unready = 6,
    PlayerRoomAction_Kicked = 7,
    PlayerRoomAction_GameOver = 8,
    PlayerRoomAction_GameLose = 9,
    RoomAction_Start = 20;


let fontSize = textSize - 2;
let imgWidth = (screenWidth - 5 * margin) / 4;
let imgHeight = (screenHeight * 2 / 3 - 3 * margin - 2 * (nameMargin + textSize)) / 2;
let imgSize = 1,
    marginHor = 1,
    marginVer = 1;
if (imgWidth < imgHeight) {
    imgSize = imgWidth;
    marginHor = margin;
    marginVer = (screenHeight * 2 / 3 - 2 * (imgSize + nameMargin + textSize)) / 3;
} else {
    imgSize = imgHeight;
    marginVer = margin;
    marginHor = (screenWidth - 4 * imgSize) / 5;
}

const
    PlayerStatus_SeatClose = 6, // 关闭的位置
    PlayerStatus_NoBody = 0, // 该位置上尚无玩家
    PlayerStatus_Waitting = 1, // 该位置上有玩家，在等待中，尚未准备
    PlayerStatus_Ready = 2, // 该位置上有玩家，已经准备了
    PlayerStatus_Playing = 3, // 该位置上有玩家，已经在游戏中
    PlayerStatus_GameOut = 4, // 该位置上有玩家，已经在游戏中被淘汰
    PlayerStatus_Offline = 5; // 该位置上有玩家，已经在游戏中，但是掉线了

export default class Room extends Scene {
    constructor() {
        super("Room");
    }

    onStart() {
        this.isStartingGame = false;
        this.ctx.font = fontSize + "px Verdana";
        this.ctx.lineWidth = 1;

        this.users = [
            [PlayerStatus_SeatClose, 'Close', marginHor, marginVer],
            [PlayerStatus_SeatClose, 'Close', marginHor * 2 + imgSize, marginVer],
            [PlayerStatus_SeatClose, 'Close', marginHor * 3 + imgSize * 2, marginVer],
            [PlayerStatus_SeatClose, 'Close', marginHor * 4 + imgSize * 3, marginVer],

            [PlayerStatus_SeatClose, 'Close', marginHor, marginVer * 2 + imgSize + nameMargin + textSize],
            [PlayerStatus_SeatClose, 'Close', marginHor * 2 + imgSize, marginVer * 2 + imgSize + nameMargin + textSize],
            [PlayerStatus_SeatClose, 'Close', marginHor * 3 + imgSize * 2, marginVer * 2 + imgSize + nameMargin + textSize],
            [PlayerStatus_SeatClose, 'Close', marginHor * 4 + imgSize * 3, marginVer * 2 + imgSize + nameMargin + textSize]
        ];
        this.mRoomActListener = this.onRoomAction.bind(this);
        this.mOfflineListener = this.onOffline.bind(this);
        model.RegistRoomActListener(this.mRoomActListener);
        model.RegistOfflineListener(this.mOfflineListener);

        // console.table(this.users);
        this.images = [new Image(), new Image(), new Image(), new Image(), new Image(), new Image(), new Image()];
        this.images[PlayerStatus_SeatClose].src = 'images/Close.png';
        this.images[PlayerStatus_NoBody].src = 'images/Nobody.png';
        this.images[PlayerStatus_Waitting].src = 'images/Waitting.png';
        this.images[PlayerStatus_Ready].src = 'images/Ready.png';
        this.images[PlayerStatus_Playing].src = 'images/Fighting.png';
        this.images[PlayerStatus_GameOut].src = 'images/Waitting.png';
        this.images[PlayerStatus_Offline].src = 'images/Waitting.png';
        this.colors = ['#888888', '#0000ff', '#00ff00', '#ff0000', '#cccccc', '#ffff00', '#00ffff', '#00ff00', '#00ff00'];

        this.mNo = -1;

        model.JoinRoom(model.get('roomId'), model.get('joinKey'), model.getUserId(), model.get('seatKey'), function(isOK, data) {
            if (isOK) {
                this.addAlert('加入房间成功');

                let
                    playerCount = data.playerCount,
                    no = data.no,
                    isPlaying = data.isPlaying,
                    players = data.players,
                    masterId = data.master;

                if (data.seatKey)
                    model.set('seatKey', data.seatKey);

                this.playerCount = playerCount;
                this.mNo = no;

                for (let i = 0; i < playerCount; i++) {
                    this.users[i][0] = players[i].status;
                    if (players[i].status == PlayerStatus_NoBody)
                        this.users[i][1] = 'Waitting';
                    else
                        this.users[i][1] = players[i].userId;
                }

                if (isPlaying) {
                    if (players[no].status == PlayerStatus_GameOut)
                        this.addAlert('你已在当前比赛中淘汰，请等待其它玩家结束游戏');
                    else
                        this.doStartGame(data);
                }
                this.isUpdated = true;
                return;
            }
            this.addAlert('加入房间失败:' + data);
            console.log(data);
            setTimeout(this.doQuitRoom.bind(this), 3000);
        }.bind(this));
    }

    onRoomAction(action, no, data) {
        console.log("第 " + no + " 玩家发送事件: " + action, data);
        let userId = data.userId;
        if (userId) {
            this.users[no][1] = data.userId;
            userId = "'" + userId + "'";
        } else
            userId = '';

        switch (action) {
            case PlayerRoomAction_Join:
                this.users[no][0] = PlayerStatus_Waitting;
                this.addAlert("玩家" + userId + "已经加入房间的" + (no + 1) + "号位");
                break;
            case PlayerRoomAction_Leave:
                this.users[no][0] = PlayerStatus_NoBody;
                this.addAlert((no + 1) + "号玩家" + userId + "已离开房间");
                break;
            case PlayerRoomAction_Ready:
                this.users[no][0] = PlayerStatus_Ready;
                this.addAlert((no + 1) + "号玩家" + userId + "已准备");
                break;
            case PlayerRoomAction_Unready:
                this.users[no][0] = PlayerStatus_Waitting;
                this.addAlert((no + 1) + "号玩家" + userId + "已取消准备");
                break;
            case PlayerRoomAction_Kicked:
                this.users[no][0] = PlayerStatus_NoBody;
                this.addAlert((no + 1) + "号玩家" + userId + "已被踢出房间");
                break;
            case RoomAction_Start:
                this.doStartGame(data);
                break;
            default:
                ZUtils.L("未知事件: " + action);
                break;
        }
        this.isUpdated = true;
    }

    onOffline() {
        this.addAlert('与服务器断开连接');
        setTimeout(this.doQuitRoom.bind(this), 3000);
    }

    addAlert(msg) {
        console.log('Alert:', msg);
        // if (this.alertTextArr)
        //     this.alertTextArr.push(msg);
        // else
        //     this.alertTextArr = [msg];
        // let count = this.alertTextArr.length;
        // if (count > 4)
        //     this.alertTextArr = this.alertTextArr.slice(count - 4);
        // this.alertText = this.alertTextArr.join('\n');
        // console.log('alertText: ' + this.alertText);
        this.alertText = msg;
        this.isUpdated = true;
    }

    onUpdate() {
        this.ctx.fillStyle = '#333333';

        let ctx = this.ctx;
        let rect;
        for (let i = 0; i < 8; i++) {
            rect = this.users[i];
            ctx.drawImage(this.images[rect[0]], rect[2], rect[3], imgSize, imgSize);
            ctx.strokeRect(rect[2], rect[3] + imgSize + nameMargin, imgSize, textSize);
            // if (i == this.mNo) { // 是我的话
            //     if (rect[0] == Status_Waitting)
            //         this.drawTextAtCenter(rect[2], rect[3] + imgSize + nameMargin, imgSize, textSize, '点击准备', fontSize, this.colors[5]);
            //     else
            //         this.drawTextAtCenter(rect[2], rect[3] + imgSize + nameMargin, imgSize, textSize, '已准备', fontSize, this.colors[6]);
            // } else
            this.drawTextAtCenter(rect[2], rect[3] + imgSize + nameMargin, imgSize, textSize, rect[1], fontSize, this.colors[rect[0]]);
        }
        ctx.strokeStyle = 'white';
        ctx.strokeRect(0, screenHeight * 2 / 3, screenWidth, screenHeight / 3);

        ctx.beginPath()
        ctx.moveTo(screenWidth * 2 / 3, screenHeight * 2 / 3);
        ctx.lineTo(screenWidth * 2 / 3, screenHeight);
        ctx.closePath();
        ctx.stroke();

        ctx.beginPath()
        ctx.moveTo(screenWidth * 5 / 6, screenHeight * 2 / 3);
        ctx.lineTo(screenWidth * 5 / 6, screenHeight);
        ctx.closePath();
        ctx.stroke();

        this.drawTextAtCenter(screenWidth * 2 / 3, screenHeight * 2 / 3, screenWidth / 6, screenHeight / 3, '准备', 28, 'white');
        this.drawTextAtCenter(screenWidth * 5 / 6, screenHeight * 2 / 3, screenWidth / 6, screenHeight / 3, '退出', 28, 'white');

        if (this.alertText)
            this.drawTextAtLeft(0, screenHeight * 2 / 3, this.alertText, 18, '#cccccc');
    }

    onTouchEvent(x, y, a, e) {
        if (a != 3)
            return;
        let isReady = this.amIReady();
        if (y > (screenHeight * 2 / 3)) { // 可能是下面的按钮
            if (x > (screenWidth * 2 / 3)) { // 是点击了
                if (x < (screenWidth * 5 / 6)) { // Ready
                    if (!isReady)
                        this.doReady();
                } else
                    this.doQuitRoom();
            }
        }
    }

    amIReady() {
        if ((this.mNo === 0 || this.mNo) && this.mNo > -1)
            return this.users[this.mNo][0] == PlayerStatus_Ready;
        return false;
    }

    doStartGame(data) {
        let playerCount = this.playerCount,
            no = this.mNo,
            startTime = data.startTime,
            nowTime = data.nowTime;
        console.log('Start game with data:', data);
        console.log('客户端时间领先服务器: ' + (new Date().getTime() - nowTime) + 'ms');
        if (playerCount > 1 && no > -1 && startTime > 0) {
            let players = [];
            for (let i = 0; i < playerCount; i++)
                players.push(this.users[i][1]);

            model.set('playerCount', playerCount).set('mNo', no).set('startTime', startTime).set('players', players);
            this.addAlert('开始进入游戏...');
            this.isStartingGame = true;
            this.loadScene('game');
        } else
            this.addAlert('进入游戏失败,数据异常');
    }

    doReady() {
        model.ReadyAtRoom();
    }

    doQuitRoom() {
        this.addAlert('正在退出房间');
        this.loadScene('lobby');
    }

    onDestroy() {
        model.UnregistRoomActListener(this.mRoomActListener);
        model.UnregistOfflineListener(this.mOfflineListener);
        this.mRoomActListener = null;
        this.mOfflineListener = null;

        this.users = [];
        this.images = [];
        this.mNo = -1;
        this.alertText = null;
        this.isUpdated = false;
        model.roomActionListener = null;
        console.log('是否需要QuitRoom:' + (this.isStartingGame != true));
        if (!this.isStartingGame)
            model.QuitRoom();
    }
}