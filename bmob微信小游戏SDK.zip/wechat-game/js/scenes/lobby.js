import Scene from '../base/scene'
import Model from '../bmobgamesdk/bgsapi'

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

console.log('Screen size = (' + screenWidth + ', ' + screenHeight + ')');

let model = Model.instance;
const
    textSize = 30,
    margin = 20;

let viewWidth = (screenWidth - 3 * margin) / 2;
let viewHeight = (screenHeight - 5 * margin) / 4;

export default class Lobby extends Scene {
    constructor() {
        super("Lobby");
    }

    onStart() {
        this.onKeyboardOK = this.onKeyboardConfirm.bind(this);
        wx.onKeyboardConfirm(this.onKeyboardOK);
        this.ctx.font = textSize + "px Verdana";

        this.btnArea = [
            [margin, margin, viewWidth, viewHeight, model.get('name'), '昵称:', '点击输入游戏内昵称'],
            [margin * 2 + viewWidth, margin, viewWidth, viewHeight, model.isDebug ? '0' : model.get('roomId'), '房间号:', '点击输入房间号'],

            [margin, margin * 2 + viewHeight, viewWidth, viewHeight, '2', '玩家数:', '点击输入玩家数'],
            [margin * 2 + viewWidth, margin * 2 + viewHeight, viewWidth, viewHeight, model.isDebug ? 'xxxxxx' : model.get('joinKey'), '房间密码:', '点击输入房间密码'],

            [margin, margin * 3 + viewHeight * 2, viewWidth, viewHeight, '创建房间', ''],
            [margin * 2 + viewWidth, margin * 3 + viewHeight * 2, viewWidth, viewHeight, '加入房间', ''],

            [margin, margin * 4 + viewHeight * 3, screenWidth - margin * 2, viewHeight, '', '', '']
        ];
    }
    onDestroy() {
        wx.offKeyboardConfirm(this.onKeyboardOK);
        this.btnArea = [];
    }
    onKeyboardConfirm(value) {
        wx.hideKeyboard();
        if (!value)
            return;
        value = value.value;
        if (!this.inputPlace)
            return;
        let inputPlace = this.inputPlace - 1;
        this.inputPlace = 0;
        this.btnArea[inputPlace][4] = value;
        switch (inputPlace) {
            case 0:
                model.setUserId(value);
                break;
        }
    }
    alert(msg) {
        this.btnArea[6][4] = msg;
        this.l(msg);
    }
    onUpdate() {
        let ctx = this.ctx;
        let rect, text, color;
        ctx.strokeStyle = 'white';
        for (let i = 0; i < 7; i++) {
            rect = this.btnArea[i];
            ctx.strokeRect(rect[0], rect[1], rect[2], rect[3]);

            text = rect[4];
            if (text) {
                text = rect[5] + text;
                color = '#cccccc';
            } else {
                text = rect[6];
                color = '#333333';
            }
            if (text)
                this.drawTextAtCenter(rect[0], rect[1], rect[2], rect[3], text, textSize, color);
        }
    }
    onTouchEvent(x, y, a, e) {
        if (a != 3)
            return;
        let touchId = -1;
        for (let i = 1; i < 6; i++) { // 昵称不允许修改
            let rect = this.btnArea[i];
            if (x < rect[0] || y < rect[1])
                continue;
            if ((x < (rect[0] + rect[2])) && (y < (rect[1] + rect[3]))) {
                touchId = i;
                break;
            }
        }
        if (touchId == -1)
            return;
        let that = this;
        switch (touchId) {
            case 0:
            case 1:
            case 2:
            case 3:
                wx.showKeyboard({
                    defaultValue: this.btnArea[touchId][4] + '',
                    maxLength: 20,
                    multiple: false,
                    confirmHold: true,
                    confirmType: 'done'
                });
                this.inputPlace = touchId + 1;
                break;
            case 4:
                if (!this.btnArea[0][4]) {
                    this.alert('请输入用户Id');
                    return;
                }
                if (this.btnArea[2][4]) {
                    let playerCount = parseInt(this.btnArea[2][4]);
                    if (playerCount > 1) {
                        this.alert('正在创建房间...');

                        model.CreateRoom(this.btnArea[0][4], playerCount, function(isOK, data) {
                            if (!that.isActive)
                                return;
                            if (isOK) {
                                let roomId = data.roomInfo.rid + '',
                                    joinKey = data.roomInfo.joinKey;
                                model.set('roomId', roomId).set('masterKey', data.roomInfo.masterKey).set('joinKey', joinKey);
                                that.btnArea[1][4] = roomId;
                                that.btnArea[3][4] = joinKey;
                                that.alert('创建成功,请加入房间');
                                return;
                            }
                            that.alert('创建失败:' + data);
                        });
                        return;
                    }
                }
                this.alert('请输入正确的玩家数(>2)');
                break;
            case 5:
                if (!this.btnArea[0][4]) {
                    this.alert('请输入用户Id');
                    return;
                }
                if (this.btnArea[1][4] === '0' || this.btnArea[1][4]) {
                    let roomId = parseInt(this.btnArea[1][4]);
                    if (roomId > -1) {
                        if (!this.btnArea[3][4]) {
                            this.alert('请输入正确的房间密码');
                            return;
                        }
                        this.alert('正在加入房间...');
                        model.set('roomId', roomId).set('joinKey', this.btnArea[3][4]);
                        this.l('Joining room: ' + roomId + ' == ' + model.get('roomId'));
                        this.loadScene('room');
                        return;
                    }
                }
                this.alert('请输入正确的房间号');
                break;
        }
    }

}