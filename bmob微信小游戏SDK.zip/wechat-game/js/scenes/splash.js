import Scene from '../base/scene'
import BGS from '../bmobgamesdk/bgsapi'

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

let model = BGS.instance;
const textSize = 36;

export default class Splash extends Scene {
    constructor() {
        super("Splash");
    }

    onStart() {
        this.alert('正在登录...');
        this.isTrying = false;
        this.tryLogin();
    }

    tryLogin() {
        if (this.isTrying)
            return;
        this.isTrying = true;
        let that = this;
        that.alert('正在初始化BGS...');
        model.Init('appkey', 'ws://[address]:[websocket-ports]', function(succ, msg) {
            if (succ) {
                that.alert('正在登录...');
                wx.login({
                    success: function(code) {
                        wx.getUserInfo({
                            success: function(res) {
                                model.login(code.code, res.userInfo, function(succ, msg) {
                                    that.alert(msg);
                                    if (succ)
                                        setTimeout(that.loadScene.bind(that, 'lobby'), 1500);
                                });
                            },
                            fail: function() {
                                that.alert('请授权获取信息');
                                that.isTrying = false;
                            }
                        });
                    },
                    fail: function() {
                        that.alert('请授权登录');
                        that.isTrying = false;
                    }
                });
            } else {
                that.alert('初始化BGS失败:' + msg);
                that.isTrying = false;
            }
        });
    }

    alert(msg) {
        this.alertText = msg;
        this.l(msg);
    }
    onUpdate() {
        this.drawTextAtCenter(0, 0, screenWidth, screenHeight, this.alertText, textSize, 'white');
        this.drawTextAtCenter(screenWidth >> 2, (screenHeight * 3) >> 2, screenWidth >> 1, 72, '版权归 Bmob 所有', 17, 'white');
    }
    onTouchEvent(x, y, a, e) {
        if (a == 3)
            this.tryLogin();
    }
    onDestroy() {}

}