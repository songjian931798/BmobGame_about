const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

let rocker_center = new Image()
rocker_center.src = 'images/rocker_c.png'
let rocker_round = new Image()
rocker_round.src = 'images/rocker_r.png'

export default class Rocker {
    constructor(ctx, size, paddings) {
        this.ctx = ctx;
        this.visible = true;
        this.x = 0, this.y = 0;
        this.touched = false;

        if (!size || size < 0)
            size = screenWidth < screenHeight ? (screenWidth >> 1) : (screenHeight >> 1);
        this.outerSize = size;
        this.innerSize = this.outerSize >> 1;
        this.innerRadius = this.innerSize >> 1;
        this.innerRadiusPow = this.innerRadius * this.innerRadius;
        let paddingLeft = 0,
            paddingTop = 0;
        if (paddings && paddings.length == 4) {
            if (paddings[0] == 0)
                paddingLeft = screenWidth - this.outerSize - paddings[2];
            else
                paddingLeft = paddings[0];
            if (paddings[1] == 0)
                paddingTop = screenHeight - this.outerSize - paddings[3];
            else
                paddingTop = paddingTop[1];
        }
        this.outerX = paddingLeft;
        this.outerY = paddingTop;
        this.centerX = paddingLeft + this.innerSize;
        this.centerY = paddingTop + this.innerSize;
        this.innerCenterX = this.centerX;
        this.innerCenterY = this.centerY;
    }
    render() {
        if (this.visible) {
            this.ctx.drawImage(rocker_round, this.outerX, this.outerY, this.outerSize, this.outerSize);
            this.ctx.drawImage(rocker_center, this.innerCenterX - this.innerRadius, this.innerCenterY - this.innerRadius, this.innerSize, this.innerSize);
        }
    }

    onTouchEvent(x, y, a) {
        if (this.visible && this.touched === (a != 1)) // 可视，且touched和ontouchstart互斥
            switch (a) {
            case 1:
                {
                    let disX = (x - this.centerX),
                        disY = (y - this.centerY);
                    if (disX * disX + disY * disY < this.innerRadiusPow) {
                        this.touched = true;
                        this.innerCenterX = x;
                        this.innerCenterY = y;

                        return true;
                    }
                    break;
                }
            case 2:
                {
                    let innerRadius = this.innerRadius,
                        centerX = this.centerX,
                        centerY = this.centerY;

                    if (x > innerRadius + centerX)
                        x = centerX + innerRadius;
                    else if (x < centerX - innerRadius)
                        x = centerX - innerRadius;
                    this.innerCenterX = x;

                    if (y > centerY + innerRadius)
                        y = centerY + innerRadius;
                    else if (y < centerY - innerRadius)
                        y = centerY - innerRadius;
                    this.innerCenterY = y;

                    // this.touch(x - centerX, y - centerY);
                    this.x = x - centerX,
                    this.y = y - centerY;
                    
                    return true;
                }
            case 3:
                {
                    this.touched = false
                    this.innerCenterX = this.centerX;
                    this.innerCenterY = this.centerY;
                    this.x = 0,
                    this.y = 0;
                    
                    return true;
                }
        }
    }
}