const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

export default class TextButton {
	// x, y, width, height, text, fontsize, color
	constructor(x, y, w, h, t, s, textColor, bgColor, listener) {
		if (!listener || (typeof(listener) !== 'function'))
			listener = function() {};
		this.listener = listener;
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.t = t;
		this.s = s;
		this.c = textColor;
		this.b = bgColor;
		this.visible = true;
	}

	onTouchEvent(x, y, a) {
		if (this.visible && x > this.x && x < this.x + this.w && y > this.y && y < this.y + this.h) {
			if (a == 3)
				this.listener();
			return true;
		}
		return false;
	}

	onDraw(ctx) {
		if (this.visible) {
			ctx.fillStyle = this.b;
			ctx.fillRect(this.x, this.y, this.w, this.h);
			if (this.t) {
				ctx.font = this.s + "px Verdana";
				if (this.c)
					ctx.fillStyle = this.c;
				ctx.fillText(this.t, this.x + (this.w - ctx.measureText(this.t).width) / 2, this.y + this.s + (this.h - this.s) / 2);
			}
		}
	}

}