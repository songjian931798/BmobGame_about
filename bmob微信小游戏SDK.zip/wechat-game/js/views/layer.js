const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

export default class Layer {
	constructor(isTouchToDismiss = true) {
		this.visible = false;
		this.color = 'rgba(0,0,0,0.5)';
		this.views = [];
		this.isTouchToDismiss = isTouchToDismiss;
		this.touchListeners = [];
	}

	setSrc(src) {
		this.img.src = src;
	}

	addView(view) {
		if (view) {
			if (view.onDraw)
				this.views.push(view);
			if (view.onTouchEvent)
				this.touchListeners.push(view);
		}
	}

	onTouchEvent(x, y, a) {
		if (this.visible) {
			let touchListeners = this.touchListeners;
			for (let i = 0, l = touchListeners.length; i < l; i++)
				if (touchListeners[i].onTouchEvent(x, y, a))
					return;
			if (a == 3 && this.isTouchToDismiss)
				this.visible = false; // 如果没有点到里面的可点击控件，隐藏layer
			return true;
		}
		return false;
	}

	show() {
		this.visible = true;
	}
	hide() {
		this.visible = false;
	}
	switchShow() {
		this.visible = !this.visible;
	}

	onDraw(ctx) {
		if (!this.visible)
			return;
		ctx.fillStyle = this.color;
		ctx.fillRect(0, 0, screenWidth, screenHeight);
		let views = this.views;
		for (let i = 0, l = views.length; i < l; i++)
			views[i].onDraw(ctx);
	}

}