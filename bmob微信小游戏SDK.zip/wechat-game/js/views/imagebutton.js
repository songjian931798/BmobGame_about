import Sprite from '../base/sprite'

const screenWidth = window.innerWidth
const screenHeight = window.innerHeight

export default class ImageButton extends Sprite {
	constructor(ctx, src, width, height, x, y, clickListener) {
		console.log('Btn x = ' + x + ' y = ' + y + ' w = ' + width + ' h = ' + height);
		super(src, width, height, x, y);
		this.ctx = ctx;
		if (!clickListener || typeof(clickListener) !== 'function')
			clickListener = function() {}
		this.listener = clickListener;
		this.isTouching = false;
		this.nextTime = 0;
	}

	setSrc(src) {
		this.img.src = src;
	}

	onTouchEvent(x, y, a) {
		if (this.visible && x > this.x && y > this.y && x < this.x + this.width && y < this.y + this.height) {
			if (this.isTouching) {
				if (a == 3) {
					this.isTouching = false;
					this.listener();
				}
			} else if (a == 1)
				this.isTouching = true;
			return true;
		}
	}

}