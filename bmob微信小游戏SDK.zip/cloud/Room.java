package cn.bmob.gamesdk.server.custom;

import java.util.HashSet;
import java.util.Set;

import cn.bmob.gamesdk.server.api.Bmob;
import cn.bmob.gamesdk.server.api.BmobGameSDKHook;
import cn.bmob.gamesdk.server.api.Functions;
import cn.bmob.gamesdk.server.api.HttpResponse;
import cn.bmob.gamesdk.server.api.JSON;
import cn.bmob.gamesdk.server.api.RoomBase;

public class Room extends RoomBase {

	static {
		Bmob.init("", "");
	}

	// 保存到Bmob数据库的id
	public String mObjectId = null;
	// 先分配队伍，后开始游戏。分配队伍这段时间，不是真正的游戏开始，不要刷怪
	public boolean isNotReallyStart;
	// 刷怪的时间间隔(毫秒)，决定了刷怪的频率，根据玩家人数来定。人越多，刷怪越快
	private long botSpawnSpan;
	// 上次刷怪的时间记录
	private long lastBotSpawnTime = 0;
	// 怪物的个数，也顺便作为id
	private long botCount = 0;
	// 置信区间: 计算击中的逻辑放到了客户端的时候，击中敌人/怪物的事件，不能完全听信其中一个客户端，防止ping差异击杀、外挂
	// 怪物还相对无关紧要，某一个客户端上报了，就选择相信他
	// 但是玩家的淘汰影响到体验，需要多个玩家同时认证的情况下判定
	// 于是约定：如果房间有2、3人，可以一个人说了算(以免掉线玩家无敌)
	// 如果有4个人玩游戏，需要2个人在短时间内"看到"某个玩家的死亡，那么这个玩家才是真正的死亡了
	// 更多人的情况下，最多只要3个人在短时间内说某个玩家死亡，就可以作出判定
	// 特殊的，如果某个玩家是汇报自己死亡，那么不用经过置信区间检测，直接判定死亡
	public int confidenceInterval = 1;
	private final Set<String> dieBotsNames = new HashSet<String>();

	public static final byte//
			NotifyType_AssignTeam = 1,//
			NotifyType_BotSpawn = 2,//
			NotifyType_ReallyStart = 3,//
			NotifyType_PlayerCrash = 4,//
			NotifyType_BotDie = 5,//
			NotifyType_GameOver = 6//
			;

	@Override
	public void onCreate() {
		// 各1个玩家的时候，1秒2个怪；以此类推
		// botSpawnSpan = (1000 / 2) / (playerCount / 2);
		botSpawnSpan = (2000) / (playerCount / 2);
		// 计算死亡判定的置信区间
		if (playerCount > 3)
			confidenceInterval = 2;
		else if (playerCount > 5)
			confidenceInterval = 3;

		HttpResponse response = Bmob.getInstance().insert("Room", JSON.toJson(//
				"roomId", roomId,//
				"master", masterId,//
				"masterKey", masterKey,//
				"joinKey", joinKey,//
				"playerCount", playerCount,//
				"address", address,//
				"tcpPort", tcpPort,//
				"udpPort", udpPort,//
				"websocketPort", websocketPort,//
				"status", 0// 0: 开启中，1: 游戏中，2:
							// 房间关闭
				));
		mObjectId = response.jsonData.getString("objectId");
	}

	@Override
	public void onGameStart() {
		if (!Functions.isStrEmpty(mObjectId))
			Bmob.getInstance().update("Room", mObjectId,
					JSON.toJson("status", 1));

		dieBotsNames.clear();
		isNotReallyStart = true;
		lastBotSpawnTime = 0;
		botCount = 0;
	}

	@Override
	public void onDestroy() {
		if (!Functions.isStrEmpty(mObjectId))
			Bmob.getInstance().update("Room", mObjectId,
					JSON.toJson("status", 2));
	}

	@Override
	@BmobGameSDKHook
	public void onTick() {
		if (isNotReallyStart)
			return;

		long curTime = getTime();
		if (curTime > lastBotSpawnTime + botSpawnSpan) {
			spawnBot();
			lastBotSpawnTime = curTime;
		}
	}

	// 游戏真正开始
	public void reallyPlaying() {
		isNotReallyStart = false;
		sendToAll(new byte[] { NotifyType_ReallyStart });
	}

	// 分配队伍
	public void assignTeam() {
		// 游戏开始，所有玩家就位了，将房间内的玩家随机、平均分到两队
		// 服务器发送到客户端的通知，就拿第一位当作消息类型的区分吧(flag)
		for (Player p : players)
			p.teamId = 0;

		// 如果[1]=1，表示players[0]是队伍1; [2]=0表示players[1]是队伍2
		byte[] team = new byte[playerCount + 1];
		// (flag)1表示分队情况
		team[0] = NotifyType_AssignTeam;
		// 其中一个队的人数
		int team1Count = playerCount / 2;
		while (team1Count != 0) {
			int id = ((int) (Math.random() * 10000) % playerCount) + 1;
			cn.bmob.gamesdk.server.Main.l("Assign team: random = " + id + " > " + team[id]);
			if (team[id] != 1) {
				players[id - 1].teamId = 1;
				team[id] = 1;
				team1Count--;
			}
		}
		sendToAll(team);
	}

	// 刷怪
	private void spawnBot() {
		botCount++;
		// 游戏里面有4种难度不同的怪，将概率按1:2:3:4来划分，越难打的怪出现几率越低
		// 位置(主要是x轴)随机，按byte表示，0-255，表示最左边到最右边，128是在屏幕中键

		// [0]表示flag，这个通知是一个刷怪事件
		// [1]表示队伍代号，这个怪是哪一边的(和assignTeam的分配一致)
		// [2]表示刷怪点x轴的位置
		// [3]表示怪物种类
		// [4-]表示怪物名(Bot[Type]_[Id])

		byte botTeam = (byte) (((int) (Math.random() * 100)) % 2);
		byte botPositionX = (byte) (((int) (Math.random() * 0xffff)) & 0xff);
		byte botType = (byte) (Math.random() * 10); // 0-9
		if (botType == 9) // 9
			botType = 3;
		else if (botType > 6) // 7、8
			botType = 2;
		else if (botType > 3) // 4、5、6
			botType = 1;
		else
			botType = 0; // 0、1、2、3，默认都是怪物0

		byte[] botName = ("Bot" + botType + "_" + Long.toHexString(botCount))
				.getBytes();
		byte[] botInfo = new byte[4 + botName.length];
		// (flag)2表示分队情况
		botInfo[0] = NotifyType_BotSpawn;
		botInfo[1] = botTeam;
		botInfo[2] = botPositionX;
		botInfo[3] = botType;
		arraycopy(botName, 0, botInfo, 4, botName.length);

		sendToAll(botInfo);
	}

	public void gameOver() {// 游戏结束
		dieBotsNames.clear();
		isNotReallyStart = true;
		dispatchGameOver();
	}

	public boolean isBotDieNow(String name) {
		return !isStrEmpty(name) && dieBotsNames.add(name);
	}

}
